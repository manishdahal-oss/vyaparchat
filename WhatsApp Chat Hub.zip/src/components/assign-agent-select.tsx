import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";

import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { assignAgent, listAgents } from "@/lib/leads.functions";
import { cn } from "@/lib/utils";

const UNASSIGNED = "__unassigned__";

interface Props {
  phone: string;
  name?: string | null;
  value: string | null;
  className?: string;
  /** Compact trigger for use inside table rows / headers. */
  size?: "sm" | "default";
}

/** Admin control that maps a customer phone number to an owning agent. */
export function AssignAgentSelect({ phone, name, value, className, size = "default" }: Props) {
  const queryClient = useQueryClient();
  const agentsFn = useServerFn(listAgents);
  const assignFn = useServerFn(assignAgent);

  const agentsQuery = useQuery({ queryKey: ["agents"], queryFn: () => agentsFn({}) });

  const mutation = useMutation({
    mutationFn: async (agentEmail: string | null) =>
      assignFn({ data: { phone, agentEmail, name: name ?? null } }),
    onSuccess: (result) => {
      void queryClient.invalidateQueries({ queryKey: ["leads"] });
      void queryClient.invalidateQueries({ queryKey: ["lead-owners"] });
      void queryClient.invalidateQueries({ queryKey: ["conversations"] });
      toast.success(
        result.agentEmail ? `Assigned to ${result.agentEmail}` : "Assignment cleared",
      );
    },
    onError: (error: Error) => toast.error(error.message),
  });

  return (
    <Select
      value={value || UNASSIGNED}
      onValueChange={(next) => mutation.mutate(next === UNASSIGNED ? null : next)}
      disabled={mutation.isPending}
    >
      <SelectTrigger
        aria-label={`Assign agent for ${phone}`}
        className={cn(size === "sm" && "h-8 text-xs", className)}
      >
        {mutation.isPending ? (
          <Loader2 className="size-3.5 animate-spin" />
        ) : (
          <SelectValue placeholder="Assign agent" />
        )}
      </SelectTrigger>
      <SelectContent>
        <SelectItem value={UNASSIGNED}>Unassigned (admin only)</SelectItem>
        {(agentsQuery.data ?? []).map((agent) => (
          <SelectItem key={agent.email} value={agent.email}>
            {agent.email} · {agent.role}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}
