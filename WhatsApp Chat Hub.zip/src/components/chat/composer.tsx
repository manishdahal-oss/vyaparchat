import { Loader2, Lock, Paperclip, Send, X } from "lucide-react";
import { useEffect, useRef, useState } from "react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { renderTemplate, type Template } from "@/lib/chat-data";

interface Props {
  windowOpen: boolean;
  templates: Template[];
  sending: boolean;
  onSendText: (text: string) => Promise<void> | void;
  onSendTemplate: (template: Template, params: string[]) => Promise<void> | void;
  onSendAttachment: (file: File, caption: string) => Promise<void> | void;
}

export function Composer({
  windowOpen,
  templates,
  sending,
  onSendText,
  onSendTemplate,
  onSendAttachment,
}: Props) {
  const [text, setText] = useState("");
  const [templateId, setTemplateId] = useState<string>("");
  const [params, setParams] = useState<string[]>([]);
  const [file, setFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const template = templates.find((t) => t.id === templateId) ?? null;

  useEffect(() => {
    setParams(Array.from({ length: template?.variable_count ?? 0 }, () => ""));
  }, [template?.id, template?.variable_count]);

  const submit = async () => {
    if (sending) return;
    if (file) {
      await onSendAttachment(file, text.trim());
      setFile(null);
      setText("");
      if (fileInputRef.current) fileInputRef.current.value = "";
      return;
    }
    const value = text.trim();
    if (!value) return;
    await onSendText(value);
    setText("");
  };

  if (!windowOpen) {
    return (
      <div className="border-t border-border bg-card px-4 py-4 sm:px-6">
        <div className="mx-auto max-w-3xl space-y-3">
          <div className="flex items-start gap-2 rounded-lg bg-warning/15 px-3 py-2.5 text-sm text-warning-foreground">
            <Lock className="mt-0.5 size-4 shrink-0" />
            <p>
              <span className="font-semibold">Template required.</span> The 24-hour customer service
              window has expired. Send an approved template to reopen the conversation.
            </p>
          </div>

          <div className="grid gap-3 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-end">
            <div className="space-y-1.5">
              <Label htmlFor="template-select" className="text-xs">
                Approved template
              </Label>
              <Select value={templateId} onValueChange={setTemplateId}>
                <SelectTrigger id="template-select" className="w-full">
                  <SelectValue placeholder="Choose a template" />
                </SelectTrigger>
                <SelectContent>
                  {templates.length === 0 && (
                    <SelectItem value="none" disabled>
                      No templates available
                    </SelectItem>
                  )}
                  {templates.map((t) => (
                    <SelectItem key={t.id} value={t.id}>
                      {t.name} · {t.language}
                      {t.category ? ` · ${t.category.toLowerCase()}` : ""}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <Button
              disabled={!template || sending}
              onClick={async () => {
                if (!template) return;
                await onSendTemplate(template, params);
              }}
            >
              {sending ? <Loader2 className="size-4 animate-spin" /> : <Send className="size-4" />}
              Send template
            </Button>
          </div>

          {template && (
            <div className="space-y-3 rounded-lg border border-border bg-secondary/60 p-3">
              {template.variable_count > 0 && (
                <div className="grid gap-2 sm:grid-cols-2">
                  {params.map((value, index) => (
                    <div key={index} className="space-y-1">
                      <Label htmlFor={`param-${index}`} className="text-xs">
                        Variable {`{{${index + 1}}}`}
                      </Label>
                      <Input
                        id={`param-${index}`}
                        value={value}
                        onChange={(event) =>
                          setParams((prev) =>
                            prev.map((p, i) => (i === index ? event.target.value : p)),
                          )
                        }
                        placeholder={`Value for {{${index + 1}}}`}
                      />
                    </div>
                  ))}
                </div>
              )}
              {template.header_type === "media" && template.header_media_url && (
                <img
                  src={template.header_media_url}
                  alt={`Header media for the ${template.name} template`}
                  loading="lazy"
                  className="max-h-40 rounded-md object-cover"
                />
              )}
              <div className="rounded-md bg-bubble-out px-3 py-2 text-sm text-bubble-out-foreground">
                {template.header_text && (
                  <p className="mb-1 font-semibold">{template.header_text}</p>
                )}
                <p className="whitespace-pre-wrap">{renderTemplate(template, params)}</p>
                {template.footer_text && (
                  <p className="mt-1 text-xs opacity-70">{template.footer_text}</p>
                )}
              </div>
              {template.buttons.length > 0 && (
                <div className="flex flex-wrap gap-2">
                  {template.buttons.map((button, index) => (
                    <span
                      key={index}
                      className="rounded-full border border-brand/40 px-3 py-1 text-xs font-medium text-brand-deep"
                    >
                      {button.text ?? "Button"}
                    </span>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="border-t border-border bg-card px-4 py-3 sm:px-6">
      <div className="mx-auto max-w-3xl space-y-2">
        {file && (
          <div className="flex items-center gap-2 rounded-lg bg-secondary px-3 py-2 text-xs">
            <Paperclip className="size-3.5 shrink-0" />
            <span className="truncate">{file.name}</span>
            <span className="text-muted-foreground">
              {(file.size / 1024 / 1024).toFixed(2)} MB
            </span>
            <Button
              variant="ghost"
              size="icon"
              className="ml-auto size-6"
              aria-label="Remove attachment"
              onClick={() => {
                setFile(null);
                if (fileInputRef.current) fileInputRef.current.value = "";
              }}
            >
              <X className="size-3.5" />
            </Button>
          </div>
        )}
        <div className="flex items-end gap-2">
          <input
            ref={fileInputRef}
            type="file"
            className="hidden"
            accept="image/*,video/*,audio/*,.pdf,.doc,.docx,.xls,.xlsx,.csv,.ppt,.pptx,.txt,.zip"
            onChange={(event) => setFile(event.target.files?.[0] ?? null)}
          />
          <Button
            variant="ghost"
            size="icon"
            className="size-11 shrink-0 rounded-full"
            disabled={sending}
            onClick={() => fileInputRef.current?.click()}
            aria-label="Attach document, image or video"
            title="Attach document, image or video"
          >
            <Paperclip className="size-5" />
          </Button>
          <Textarea
            value={text}
            onChange={(event) => setText(event.target.value)}
            onKeyDown={(event) => {
              if (event.key === "Enter" && !event.shiftKey) {
                event.preventDefault();
                void submit();
              }
            }}
            placeholder={file ? "Add a caption (optional)" : "Type a message"}
            aria-label="Message"
            rows={1}
            className="max-h-40 min-h-11 flex-1 resize-none rounded-2xl bg-secondary"
          />
          <Button
            size="icon"
            className="size-11 shrink-0 rounded-full"
            disabled={(!text.trim() && !file) || sending}
            onClick={() => void submit()}
            aria-label="Send message"
          >
            {sending ? <Loader2 className="size-4 animate-spin" /> : <Send className="size-4" />}
          </Button>
        </div>
      </div>
    </div>
  );
}
