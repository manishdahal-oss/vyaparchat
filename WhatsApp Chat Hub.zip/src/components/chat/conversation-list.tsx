import { Search, MessageSquareDashed } from "lucide-react";
import { useMemo, useState } from "react";

import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import {
  displayName,
  formatPhone,
  formatTime,
  initials,
  windowStatus,
  type Conversation,
} from "@/lib/chat-data";
import type { Lead } from "@/lib/leads";
import { cn } from "@/lib/utils";

interface Props {
  conversations: Conversation[];
  activeId: string | null;
  loading: boolean;
  onSelect: (conversation: Conversation) => void;
  action?: React.ReactNode;
  /** phone -> lead record, used to show who owns the chat. */
  owners?: Record<string, Lead>;
  /** Admins see the owning agent on every row. */
  showOwner?: boolean;
}

export function ConversationList({
  conversations,
  activeId,
  loading,
  onSelect,
  action,
  owners = {},
  showOwner = false,
}: Props) {
  const [query, setQuery] = useState("");

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return conversations;
    return conversations.filter(
      (c) => (c.name ?? "").toLowerCase().includes(q) || c.phone.includes(q.replace(/\D/g, "")),
    );
  }, [conversations, query]);

  return (
    <div className="flex h-full flex-col bg-sidebar">
      <div className="border-b border-sidebar-border px-4 py-3">
        <div className="flex items-center justify-between gap-2">
          <h2 className="text-sm font-semibold tracking-tight text-sidebar-foreground">
            Recent chats
          </h2>
          {action}
        </div>
        <div className="relative mt-3">
          <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search name or number"
            aria-label="Search conversations"
            className="h-9 rounded-full bg-secondary pl-9 text-sm"
          />
        </div>
      </div>

      <div className="scroll-slim flex-1 overflow-y-auto">
        {loading ? (
          <ul className="space-y-1 p-3">
            {[0, 1, 2, 3, 4].map((i) => (
              <li key={i} className="flex items-center gap-3 px-1 py-2">
                <Skeleton className="size-11 rounded-full" />
                <div className="flex-1 space-y-2">
                  <Skeleton className="h-3 w-1/2" />
                  <Skeleton className="h-3 w-4/5" />
                </div>
              </li>
            ))}
          </ul>
        ) : filtered.length === 0 ? (
          <div className="flex flex-col items-center gap-2 px-6 py-16 text-center">
            <MessageSquareDashed className="size-8 text-muted-foreground" />
            <p className="text-sm text-muted-foreground">
              {query ? "No conversations match your search." : "No conversations yet."}
            </p>
          </div>
        ) : (
          <ul>
            {filtered.map((conversation) => {
              const active = conversation.id === activeId;
              const { active: windowOpen } = windowStatus(conversation);
              return (
                <li key={conversation.id}>
                  <button
                    type="button"
                    onClick={() => onSelect(conversation)}
                    aria-current={active}
                    className={cn(
                      "flex w-full items-center gap-3 border-b border-sidebar-border/60 px-4 py-3 text-left transition-colors",
                      active ? "bg-sidebar-accent" : "hover:bg-sidebar-accent/60",
                    )}
                  >
                    <span className="relative flex size-11 shrink-0 items-center justify-center rounded-full bg-brand/15 text-sm font-semibold text-brand-deep">
                      {initials(conversation)}
                      <span
                        className={cn(
                          "absolute right-0 bottom-0 size-3 rounded-full border-2 border-sidebar",
                          windowOpen ? "bg-success" : "bg-muted-foreground/50",
                        )}
                        aria-hidden
                      />
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="flex items-baseline justify-between gap-2">
                        <span className="truncate text-sm font-semibold">
                          {displayName(conversation)}
                        </span>
                        <span className="shrink-0 text-[11px] text-muted-foreground">
                          {formatTime(conversation.last_message_at)}
                        </span>
                      </span>
                      <span className="mt-0.5 flex items-center justify-between gap-2">
                        <span className="truncate text-xs text-muted-foreground">
                          {conversation.last_message ?? formatPhone(conversation.phone)}
                        </span>
                        {conversation.unread_count > 0 && (
                          <span className="inline-flex min-w-5 shrink-0 items-center justify-center rounded-full bg-brand px-1.5 text-[11px] font-semibold text-brand-foreground">
                            {conversation.unread_count}
                          </span>
                        )}
                      </span>
                      {showOwner ? (
                        <span className="mt-1 inline-flex max-w-full items-center gap-1 truncate rounded-full px-2 py-0.5 text-[10px] font-medium">
                          <span
                            className={cn(
                              "truncate rounded-full px-2 py-0.5",
                              owners[conversation.phone]?.agent_email
                                ? "bg-brand/10 text-brand-deep"
                                : "bg-warning/20 text-warning-foreground",
                            )}
                          >
                            {owners[conversation.phone]?.agent_email ?? "Unassigned lead"}
                          </span>
                        </span>
                      ) : null}
                    </span>
                  </button>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </div>
  );
}
