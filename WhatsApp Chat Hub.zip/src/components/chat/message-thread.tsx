import {
  AlertCircle,
  Check,
  CheckCheck,
  Clock,
  Download,
  FileText,
  LayoutTemplate,
} from "lucide-react";
import { useEffect, useRef } from "react";

import { Skeleton } from "@/components/ui/skeleton";
import type { ChatMessage } from "@/lib/chat-data";
import { cn } from "@/lib/utils";

function StatusIcon({ status }: { status: string }) {
  if (status === "pending") return <Clock className="size-3.5" aria-label="Sending" />;
  if (status === "failed")
    return <AlertCircle className="size-3.5 text-destructive" aria-label="Failed" />;
  if (status === "read") return <CheckCheck className="size-3.5 text-brand" aria-label="Read" />;
  if (status === "delivered") return <CheckCheck className="size-3.5" aria-label="Delivered" />;
  return <Check className="size-3.5" aria-label="Sent" />;
}

function dayLabel(iso: string) {
  const date = new Date(iso);
  const today = new Date();
  if (date.toDateString() === today.toDateString()) return "Today";
  const yesterday = new Date(today.getTime() - 86400000);
  if (date.toDateString() === yesterday.toDateString()) return "Yesterday";
  return date.toLocaleDateString([], { day: "numeric", month: "long", year: "numeric" });
}

const EXT_KIND: Record<string, "image" | "video" | "audio"> = {
  png: "image",
  jpg: "image",
  jpeg: "image",
  webp: "image",
  gif: "image",
  bmp: "image",
  mp4: "video",
  mov: "video",
  webm: "video",
  "3gp": "video",
  mp3: "audio",
  ogg: "audio",
  oga: "audio",
  wav: "audio",
  m4a: "audio",
  aac: "audio",
};

function attachmentInfo(url: string, type: string) {
  let pathname = url;
  try {
    pathname = new URL(url).pathname;
  } catch {
    /* relative or malformed url — use as-is */
  }
  const rawName = decodeURIComponent(pathname.split("/").pop() ?? "attachment");
  const fileName = rawName.replace(/^\d{10,}-[a-z0-9]{4,8}-/i, "") || "attachment";
  const ext = fileName.split(".").pop()?.toLowerCase() ?? "";
  const normalized = (type || "").toLowerCase();
  const kind =
    normalized === "image" || normalized === "video" || normalized === "audio"
      ? normalized
      : (EXT_KIND[ext] ?? "document");
  return { fileName, ext, kind };
}

function Attachment({ url, type }: { url: string; type: string }) {
  const { fileName, ext, kind } = attachmentInfo(url, type);


  return (
    <div className="mb-2 space-y-1.5">
      {kind === "image" && (
        <a href={url} target="_blank" rel="noreferrer">
          <img
            src={url}
            alt={fileName}
            loading="lazy"
            className="max-h-64 rounded-lg object-cover"
          />
        </a>
      )}
      {kind === "video" && <video src={url} controls className="max-h-64 rounded-lg" />}
      {kind === "audio" && <audio src={url} controls className="w-56" />}
      {kind === "document" && (
        <a
          href={url}
          target="_blank"
          rel="noreferrer"
          className="flex items-center gap-2 rounded-lg bg-black/5 px-3 py-2 text-xs font-medium"
        >
          <FileText className="size-5 shrink-0" />
          <span className="min-w-0 flex-1">
            <span className="block truncate">{fileName}</span>
            {ext && <span className="block opacity-60 uppercase">{ext} file</span>}
          </span>
        </a>
      )}
      <a
        href={url}
        download={fileName}
        target="_blank"
        rel="noreferrer"
        className="inline-flex items-center gap-1.5 rounded-full bg-black/5 px-2.5 py-1 text-[11px] font-medium underline-offset-2 hover:underline"
      >
        <Download className="size-3.5" />
        Download {fileName}
      </a>
    </div>
  );
}

interface Props {
  messages: ChatMessage[];
  loading: boolean;
  error?: string | null;
}

export function MessageThread({ messages, loading, error }: Props) {
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ block: "end" });
  }, [messages.length]);

  if (loading) {
    return (
      <div className="chat-canvas scroll-slim flex-1 space-y-4 overflow-y-auto p-6">
        {[0, 1, 2].map((i) => (
          <div key={i} className={cn("flex", i % 2 ? "justify-end" : "justify-start")}>
            <Skeleton className="h-14 w-56 rounded-2xl" />
          </div>
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <div className="chat-canvas flex flex-1 items-center justify-center p-6">
        <p className="rounded-lg bg-destructive/10 px-4 py-3 text-sm text-destructive">{error}</p>
      </div>
    );
  }

  let lastDay = "";

  return (
    <div className="chat-canvas scroll-slim flex-1 overflow-y-auto px-4 py-6 sm:px-8">
      <div className="mx-auto flex max-w-3xl flex-col gap-1.5">
        {messages.length === 0 && (
          <p className="mx-auto rounded-full bg-card px-4 py-2 text-xs text-muted-foreground shadow-bubble">
            No messages yet — start the conversation below.
          </p>
        )}
        {messages.map((message) => {
          const outgoing = message.direction === "outgoing";
          const label = dayLabel(message.created_at);
          const showDay = label !== lastDay;
          lastDay = label;

          return (
            <div key={message.id}>
              {showDay && (
                <div className="my-4 flex justify-center">
                  <span className="rounded-full bg-card px-3 py-1 text-[11px] font-medium text-muted-foreground shadow-bubble">
                    {label}
                  </span>
                </div>
              )}
              <div className={cn("flex", outgoing ? "justify-end" : "justify-start")}>
                <div
                  className={cn(
                    "max-w-[85%] rounded-2xl px-3.5 py-2 shadow-bubble sm:max-w-[70%]",
                    outgoing
                      ? "rounded-br-sm bg-bubble-out text-bubble-out-foreground"
                      : "rounded-bl-sm bg-bubble-in text-bubble-in-foreground",
                  )}
                >
                  {message.template_name && (
                    <p className="mb-1 flex items-center gap-1.5 text-[11px] font-semibold tracking-wide uppercase opacity-70">
                      <LayoutTemplate className="size-3" />
                      {message.template_name}
                    </p>
                  )}
                  {message.media_url && (
                    <Attachment
                      url={message.media_url}
                      type={message.message_type}
                    />
                  )}
                  <p className="text-sm leading-relaxed whitespace-pre-wrap">{message.body}</p>
                  <p className="mt-1 flex items-center justify-end gap-1 text-[10px] opacity-65">
                    {new Date(message.created_at).toLocaleTimeString([], {
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                    {outgoing && <StatusIcon status={message.status} />}
                  </p>
                  {message.status === "failed" && message.error && (
                    <p className="mt-1 text-[11px] text-destructive">{message.error}</p>
                  )}
                </div>
              </div>
            </div>
          );
        })}
        <div ref={bottomRef} />
      </div>
    </div>
  );
}
