import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import {
  Check,
  CheckCircle2,
  Copy,
  Loader2,
  RefreshCw,
  Send,
  XCircle,
  Zap,
} from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { listProviderTemplates } from "@/lib/templates.functions";
import { cn } from "@/lib/utils";

export interface PushLogEntry {
  id: string;
  at: string;
  phone: string;
  messageType: string;
  ok: boolean;
  status: number;
  detail: string;
}

export interface PushRequest {
  phone: string;
  messageType: string;
  bodyParam: string;
  params: string[];
  language: string;
}

interface Props {
  sending: boolean;
  log: PushLogEntry[];
  onPush: (request: PushRequest) => Promise<void> | void;
}

function buildCurl({ phone, messageType, params, language }: PushRequest) {
  const payload = {
    messaging_product: "whatsapp",
    recipient_type: "individual",
    to: phone,
    type: "template",
    template: {
      name: messageType,
      language: { code: language },
      ...(params.length
        ? {
            components: [
              {
                type: "body",
                parameters: params.map((text) => ({ type: "text", text })),
              },
            ],
          }
        : {}),
    },
  };

  return `curl --location 'https://vyaparm2d.timespanel.in/wa/v2/messages/send' \\
--header 'Authorization: ********' \\
--header 'Content-Type: application/json' \\
--data '${JSON.stringify(payload)}'`;
}

/** Renders the template text with the agent's values substituted for {{n}}. */
function renderPreview(text: string, params: string[]) {
  return text.replace(/\{\{\s*(\d+)\s*\}\}/g, (_m, index: string) => {
    const value = params[Number(index) - 1];
    return value?.trim() ? value : `{{${index}}}`;
  });
}

export function PushMessageDialog({ sending, log, onPush }: Props) {
  const [open, setOpen] = useState(false);
  const [phone, setPhone] = useState("");
  const [messageType, setMessageType] = useState("");
  const [params, setParams] = useState<string[]>([]);
  const [copied, setCopied] = useState(false);

  const templatesFn = useServerFn(listProviderTemplates);
  const templatesQuery = useQuery({
    queryKey: ["provider-templates"],
    queryFn: () => templatesFn({}),
    enabled: open,
    staleTime: 60_000,
  });

  const templates = useMemo(() => templatesQuery.data?.templates ?? [], [templatesQuery.data]);
  const selected = templates.find((t) => t.name === messageType) ?? null;

  // Default to the first template once the list arrives.
  useEffect(() => {
    if (!messageType && templates.length) setMessageType(templates[0]!.name);
  }, [templates, messageType]);

  useEffect(() => {
    setParams(Array.from({ length: selected?.variableCount ?? 0 }, () => ""));
  }, [selected?.name, selected?.variableCount]);

  const digits = phone.replace(/\D/g, "");
  const valid = digits.length >= 10 && Boolean(messageType);

  const request: PushRequest = {
    phone: digits,
    messageType,
    bodyParam: params[0]?.trim() ?? "",
    params: params.map((p) => p.trim()).filter(Boolean),
    language: selected?.language ?? "en",
  };
  const curl = buildCurl(request);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(curl);
      setCopied(true);
      toast.success("Curl copied to clipboard");
      setTimeout(() => setCopied(false), 1500);
    } catch {
      toast.error("Could not copy curl");
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="gap-1.5">
          <Zap className="size-4" />
          Push message
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>Push a message</DialogTitle>
          <DialogDescription>
            Enter the customer number and pick an approved template pulled live from the provider.
          </DialogDescription>
        </DialogHeader>

        <div className="scroll-slim max-h-[70vh] space-y-3 overflow-y-auto pr-1">
          <div className="space-y-1.5">
            <Label htmlFor="push-phone">Phone number</Label>
            <Input
              id="push-phone"
              inputMode="tel"
              value={phone}
              onChange={(event) => setPhone(event.target.value)}
              placeholder="919611272070"
            />
          </div>

          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <Label htmlFor="push-type">Template</Label>
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="h-7 gap-1.5 px-2 text-xs"
                onClick={() => void templatesQuery.refetch()}
                disabled={templatesQuery.isFetching}
              >
                <RefreshCw
                  className={cn("size-3.5", templatesQuery.isFetching && "animate-spin")}
                />
                Refresh list
              </Button>
            </div>
            <Select value={messageType} onValueChange={setMessageType}>
              <SelectTrigger id="push-type" className="w-full">
                <SelectValue
                  placeholder={
                    templatesQuery.isLoading ? "Loading templates…" : "Select a template"
                  }
                />
              </SelectTrigger>
              <SelectContent>
                {templates.map((template) => (
                  <SelectItem key={`${template.name}-${template.language}`} value={template.name}>
                    {template.name} · {template.language} · {template.status}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {templatesQuery.data && "notice" in templatesQuery.data && templatesQuery.data.notice ? (
              <p className="text-xs text-muted-foreground">{templatesQuery.data.notice}</p>
            ) : null}
            {templatesQuery.data?.error ? (
              <p className="text-xs text-destructive">{templatesQuery.data.error}</p>
            ) : null}

            {templatesQuery.error ? (
              <p className="text-xs text-destructive">
                {(templatesQuery.error as Error).message}
              </p>
            ) : null}
          </div>

          {selected ? (
            <div className="space-y-2 rounded-lg border border-border bg-secondary/50 p-3">
              <div className="flex flex-wrap items-center gap-2 text-[11px] text-muted-foreground">
                <span className="rounded-full bg-brand/10 px-2 py-0.5 text-brand-deep">
                  {selected.status}
                </span>
                {selected.category ? <span>{selected.category}</span> : null}
                <span>{selected.language}</span>
                <span>
                  {selected.variableCount} variable{selected.variableCount === 1 ? "" : "s"}
                </span>
              </div>
              {selected.headerText ? (
                <p className="text-xs font-semibold">
                  {renderPreview(selected.headerText, params)}
                </p>
              ) : null}
              <p className="text-sm whitespace-pre-wrap">
                {renderPreview(selected.bodyText, params) || "(no body text)"}
              </p>
              {selected.footerText ? (
                <p className="text-[11px] text-muted-foreground">{selected.footerText}</p>
              ) : null}
              {selected.buttons.length ? (
                <div className="flex flex-wrap gap-1.5">
                  {selected.buttons.map((button) => (
                    <span
                      key={button}
                      className="rounded-md border border-border bg-card px-2 py-0.5 text-[11px]"
                    >
                      {button}
                    </span>
                  ))}
                </div>
              ) : null}
            </div>
          ) : null}

          {params.length ? (
            <div className="grid gap-3 sm:grid-cols-2">
              {params.map((value, index) => (
                <div key={index} className="space-y-1.5">
                  <Label htmlFor={`push-param-${index}`}>
                    Variable {`{{${index + 1}}}`}
                  </Label>
                  <Input
                    id={`push-param-${index}`}
                    value={value}
                    onChange={(event) =>
                      setParams((prev) =>
                        prev.map((p, i) => (i === index ? event.target.value : p)),
                      )
                    }
                    placeholder={`value ${index + 1}`}
                  />
                </div>
              ))}
            </div>
          ) : null}

          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <Label>Request curl preview</Label>
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="h-7 gap-1.5 px-2 text-xs"
                onClick={handleCopy}
              >
                {copied ? <Check className="size-3.5" /> : <Copy className="size-3.5" />}
                {copied ? "Copied" : "Copy curl"}
              </Button>
            </div>
            <div className="relative">
              <pre className="scroll-slim max-h-56 overflow-auto rounded-lg border border-border bg-secondary p-3 text-[11px] leading-relaxed whitespace-pre-wrap break-all">
                {curl}
              </pre>
            </div>
          </div>

          <Button
            className="w-full"
            disabled={!valid || sending}
            onClick={async () => {
              await onPush(request);
            }}
          >
            {sending ? <Loader2 className="size-4 animate-spin" /> : <Send className="size-4" />}
            Push {messageType || "template"}
          </Button>

          <div className="space-y-2">
            <p className="text-xs font-semibold text-muted-foreground">Push log</p>
            <div className="scroll-slim max-h-56 space-y-2 overflow-y-auto rounded-lg border border-border bg-secondary/50 p-2">
              {log.length === 0 ? (
                <p className="px-1 py-3 text-center text-xs text-muted-foreground">
                  No pushes yet in this session.
                </p>
              ) : (
                log.map((entry) => (
                  <div
                    key={entry.id}
                    className={cn(
                      "rounded-md border bg-card p-2 text-xs",
                      entry.ok ? "border-success/40" : "border-destructive/40",
                    )}
                  >
                    <div className="flex items-center gap-1.5 font-medium">
                      {entry.ok ? (
                        <CheckCircle2 className="size-3.5 text-success" />
                      ) : (
                        <XCircle className="size-3.5 text-destructive" />
                      )}
                      <span>{entry.ok ? "Success" : "Failed"}</span>
                      <span className="text-muted-foreground">
                        · {entry.messageType} · {entry.phone} · HTTP {entry.status || "—"}
                      </span>
                      <span className="ml-auto text-muted-foreground">{entry.at}</span>
                    </div>
                    <pre className="mt-1 max-h-24 overflow-auto break-all whitespace-pre-wrap text-[11px] text-muted-foreground">
                      {entry.detail}
                    </pre>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
