import { Link } from "@tanstack/react-router";
import { CircleAlert, LogOut, MessageCircle, ShieldCheck } from "lucide-react";

import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { cn } from "@/lib/utils";

interface Props {
  email: string;
  isAdmin: boolean;
  sendApiConfigured?: boolean | undefined;
}

const NAV = [
  { to: "/", label: "Home", adminOnly: false },
  { to: "/leads", label: "Leads", adminOnly: false },
  { to: "/templates", label: "Templates", adminOnly: true },
  { to: "/team", label: "Team", adminOnly: true },
] as const;


export function PortalHeader({ email, isAdmin, sendApiConfigured }: Props) {
  return (
    <header className="flex flex-wrap items-center justify-between gap-3 border-b border-border bg-brand px-4 py-3 text-brand-foreground sm:px-6">
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2.5">
          <MessageCircle className="size-5" />
          <div>
            <h1 className="text-sm font-semibold tracking-tight">Customer Chat Portal</h1>
            <p className="text-[11px] opacity-80">WhatsApp Business inbox</p>
          </div>
        </div>
        <nav className="flex items-center gap-1 text-xs font-medium" aria-label="Main">
          {NAV.filter((item) => !item.adminOnly || isAdmin).map((item) => (
            <Link

              key={item.to}
              to={item.to}
              activeOptions={{ exact: item.to === "/" }}
              className="rounded-full px-3 py-1.5 opacity-80 transition-colors hover:bg-brand-foreground/15"
              activeProps={{ className: cn("bg-brand-foreground/20 opacity-100") }}
            >
              {item.label}
            </Link>
          ))}
        </nav>
      </div>

      <div className="flex items-center gap-2 text-[11px]">
        {sendApiConfigured === undefined ? null : sendApiConfigured ? (
          <span className="inline-flex items-center gap-1 rounded-full bg-brand-foreground/15 px-2.5 py-1">
            <ShieldCheck className="size-3.5" /> Send API connected
          </span>
        ) : (
          <span className="inline-flex items-center gap-1 rounded-full bg-brand-foreground/15 px-2.5 py-1">
            <CircleAlert className="size-3.5" /> Send API not configured
          </span>
        )}
        <span className="hidden rounded-full bg-brand-foreground/15 px-2.5 py-1 sm:inline">
          {email}
          {isAdmin ? " · Admin" : " · Agent"}
        </span>
        <Button
          variant="ghost"
          size="sm"
          className="h-7 gap-1.5 px-2 text-[11px] text-brand-foreground hover:bg-brand-foreground/15 hover:text-brand-foreground"
          onClick={async () => {
            await supabase.auth.signOut();
            window.location.href = "/auth";
          }}
        >
          <LogOut className="size-3.5" /> Sign out
        </Button>
      </div>
    </header>
  );
}
