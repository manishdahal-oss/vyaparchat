import { useEffect, useState } from "react";

import { supabase } from "@/integrations/supabase/client";

export interface Staff {
  email: string;
  isAdmin: boolean;
  loading: boolean;
}

/** Current signed-in staff member plus whether they hold the admin role. */
export function useStaff(): Staff {
  const [email, setEmail] = useState("");
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;

    const load = async () => {
      const { data } = await supabase.auth.getUser();
      const user = data.user;
      if (!user) {
        if (!cancelled) setLoading(false);
        return;
      }
      const { data: roles } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", user.id);
      if (cancelled) return;
      setEmail(user.email ?? "");
      setIsAdmin((roles ?? []).some((r) => r.role === "admin"));
      setLoading(false);
    };

    void load();
    return () => {
      cancelled = true;
    };
  }, []);

  return { email, isAdmin, loading };
}
