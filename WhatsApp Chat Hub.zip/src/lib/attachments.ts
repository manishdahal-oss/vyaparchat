export type MediaKind = "image" | "video" | "document" | "audio";

/** Maps a browser File to the WhatsApp media type. */
export function mediaKindFor(contentType: string, fileName: string): MediaKind {
  const type = (contentType || "").toLowerCase();
  if (type.startsWith("image/")) return "image";
  if (type.startsWith("video/")) return "video";
  if (type.startsWith("audio/")) return "audio";
  const ext = fileName.split(".").pop()?.toLowerCase() ?? "";
  if (["png", "jpg", "jpeg", "webp", "gif"].includes(ext)) return "image";
  if (["mp4", "mov", "3gp", "mkv"].includes(ext)) return "video";
  if (["mp3", "ogg", "wav", "m4a"].includes(ext)) return "audio";
  return "document";
}

/** Reads a file as raw base64 (no data: prefix) for upload through a server function. */
export function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("The file could not be read"));
    reader.onload = () => {
      const result = String(reader.result ?? "");
      resolve(result.slice(result.indexOf(",") + 1));
    };
    reader.readAsDataURL(file);
  });
}
