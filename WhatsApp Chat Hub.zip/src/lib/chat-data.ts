import { supabase } from "@/integrations/supabase/client";

export interface Conversation {
  id: string;
  phone: string;
  name: string | null;
  last_message: string | null;
  last_message_at: string | null;
  last_inbound_at: string | null;
  unread_count: number;
}

export interface ChatMessage {
  id: string;
  conversation_id: string;
  phone: string;
  wa_message_id: string | null;
  direction: string;
  message_type: string;
  body: string | null;
  media_url: string | null;
  template_name: string | null;
  status: string;
  error: string | null;
  created_at: string;
}

export interface Template {
  id: string;
  name: string;
  language: string;
  category: string | null;
  header_type: string;
  header_text: string | null;
  header_media_url: string | null;
  body_text: string;
  footer_text: string | null;
  buttons: { type?: string; text?: string }[];
  variable_count: number;
  status: string;
}

export const WINDOW_MS = 24 * 60 * 60 * 1000;

export function windowStatus(conversation: Conversation | null | undefined) {
  if (!conversation?.last_inbound_at) {
    return { active: false, msLeft: 0 };
  }
  const msLeft = new Date(conversation.last_inbound_at).getTime() + WINDOW_MS - Date.now();
  return { active: msLeft > 0, msLeft: Math.max(msLeft, 0) };
}

export function formatCountdown(ms: number) {
  const totalMinutes = Math.floor(ms / 60000);
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  if (hours > 0) return `${hours}h ${minutes}m left`;
  return `${minutes}m left`;
}

export function formatTime(iso: string | null) {
  if (!iso) return "";
  const date = new Date(iso);
  const today = new Date();
  const sameDay = date.toDateString() === today.toDateString();
  if (sameDay) {
    return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  }
  const yesterday = new Date(today.getTime() - 86400000);
  if (date.toDateString() === yesterday.toDateString()) return "Yesterday";
  return date.toLocaleDateString([], { day: "2-digit", month: "short" });
}

export function formatPhone(phone: string) {
  return `+${phone}`;
}

export function displayName(conversation: Conversation) {
  return conversation.name?.trim() || formatPhone(conversation.phone);
}

export function initials(conversation: Conversation) {
  const name = conversation.name?.trim();
  if (!name) return conversation.phone.slice(-2);
  return name
    .split(/\s+/)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase() ?? "")
    .join("");
}

export async function fetchConversations(): Promise<Conversation[]> {
  const { data, error } = await supabase
    .from("conversations")
    .select("id, phone, name, last_message, last_message_at, last_inbound_at, unread_count")
    .order("last_message_at", { ascending: false, nullsFirst: false });
  if (error) throw new Error(error.message);
  return (data ?? []) as Conversation[];
}

export async function fetchMessages(conversationId: string): Promise<ChatMessage[]> {
  const { data, error } = await supabase
    .from("messages")
    .select("*")
    .eq("conversation_id", conversationId)
    .order("created_at", { ascending: true });
  if (error) throw new Error(error.message);
  return (data ?? []) as ChatMessage[];
}

export async function fetchTemplates(): Promise<Template[]> {
  const { data, error } = await supabase
    .from("templates")
    .select("*")
    .order("name", { ascending: true });
  if (error) throw new Error(error.message);
  return (data ?? []) as unknown as Template[];
}

export function renderTemplate(template: Template, params: string[]) {
  return template.body_text.replace(/\{\{(\d+)\}\}/g, (match, index: string) => {
    const value = params[Number(index) - 1];
    return value?.trim() ? value : match;
  });
}
