import { createServerFn } from "@tanstack/react-start";

import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export interface LeadUpload {
  name?: string | null;
  phone: string;
  agent_email?: string | null;
  source?: string | null;
}

async function assertAdmin(context: { supabase: any; userId: string }) {
  const { data, error } = await context.supabase.rpc("has_role", {
    _user_id: context.userId,
    _role: "admin",
  });
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Only admins can manage leads");
}

/** Admin-only: list the staff accounts a lead can be assigned to. */
export const listAgents = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context as never);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data } = await supabaseAdmin.auth.admin.listUsers({ page: 1, perPage: 200 });
    const { data: roles } = await supabaseAdmin.from("user_roles").select("user_id, role");
    const roleFor = new Map((roles ?? []).map((r) => [r.user_id, r.role]));
    return (data?.users ?? [])
      .filter((u) => Boolean(u.email))
      .map((u) => ({ email: u.email as string, role: roleFor.get(u.id) ?? "agent" }))
      .sort((a, b) => a.email.localeCompare(b.email));
  });

/** Admin-only: insert or update leads (single entry or bulk upload). */
export const upsertLeads = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { leads: LeadUpload[] }) => {
    if (!input?.leads?.length) throw new Error("No leads to upload");
    if (input.leads.length > 5000) throw new Error("Please upload at most 5000 leads at a time");
    return input;
  })
  .handler(async ({ data, context }) => {
    await assertAdmin(context as never);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const seen = new Set<string>();
    const rows = [];
    const skipped: string[] = [];

    for (const lead of data.leads) {
      const phone = String(lead.phone ?? "").replace(/\D/g, "").replace(/^0+/, "");
      if (phone.length < 8) {
        skipped.push(`${lead.phone || "(blank)"} — invalid phone number`);
        continue;
      }
      const email = lead.agent_email?.trim().toLowerCase() || null;
      if (email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
        skipped.push(`${phone} — invalid agent email "${lead.agent_email}"`);
        continue;
      }
      if (seen.has(phone)) continue;
      seen.add(phone);
      rows.push({
        phone,
        name: lead.name?.trim() || null,
        agent_email: email,
        source: lead.source?.trim() || null,
        updated_at: new Date().toISOString(),
      });
    }

    if (!rows.length) return { saved: 0, skipped, unassigned: 0 };

    const { error } = await supabaseAdmin.from("leads").upsert(rows, { onConflict: "phone" });
    if (error) throw new Error(error.message);

    // Keep conversation display names in sync with the lead name.
    for (const row of rows) {
      if (!row.name) continue;
      await supabaseAdmin
        .from("conversations")
        .update({ name: row.name })
        .eq("phone", row.phone)
        .is("name", null);
    }

    return {
      saved: rows.length,
      skipped,
      unassigned: rows.filter((r) => !r.agent_email).length,
    };
  });

/** Admin-only: delete a lead. */
export const deleteLead = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { id: string }) => {
    if (!input?.id) throw new Error("Lead id is required");
    return input;
  })
  .handler(async ({ data, context }) => {
    await assertAdmin(context as never);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.from("leads").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

/** Admin-only: assign (or clear) the agent that owns a phone number. Creates the lead if missing. */
export const assignAgent = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { phone: string; agentEmail: string | null; name?: string | null }) => {
    const phone = String(input?.phone ?? "").replace(/\D/g, "").replace(/^0+/, "");
    if (phone.length < 8) throw new Error("A valid phone number is required");
    const agentEmail = input.agentEmail?.trim().toLowerCase() || null;
    if (agentEmail && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(agentEmail))
      throw new Error("Invalid agent email");
    return { phone, agentEmail, name: input.name?.trim() || null };
  })
  .handler(async ({ data, context }) => {
    await assertAdmin(context as never);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: existing } = await supabaseAdmin
      .from("leads")
      .select("id")
      .eq("phone", data.phone)
      .maybeSingle();

    if (existing) {
      const { error } = await supabaseAdmin
        .from("leads")
        .update({ agent_email: data.agentEmail, updated_at: new Date().toISOString() })
        .eq("id", existing.id);
      if (error) throw new Error(error.message);
    } else {
      const { error } = await supabaseAdmin.from("leads").insert({
        phone: data.phone,
        name: data.name,
        agent_email: data.agentEmail,
        source: "assigned from portal",
      });
      if (error) throw new Error(error.message);
    }
    return { ok: true, phone: data.phone, agentEmail: data.agentEmail };
  });
