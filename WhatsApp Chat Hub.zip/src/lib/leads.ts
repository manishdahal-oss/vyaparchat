import { supabase } from "@/integrations/supabase/client";

export interface Lead {
  id: string;
  name: string | null;
  phone: string;
  agent_email: string | null;
  source: string | null;
  created_at: string;
  updated_at: string;
}

export interface LeadInput {
  name?: string | null;
  phone: string;
  agent_email?: string | null;
  source?: string | null;
}

/** Digits-only phone, matching how conversations store numbers. */
export function cleanPhone(value: string) {
  return (value ?? "").replace(/\D/g, "").replace(/^0+/, "");
}

export async function fetchLeads(): Promise<Lead[]> {
  const { data, error } = await supabase
    .from("leads")
    .select("id, name, phone, agent_email, source, created_at, updated_at")
    .order("updated_at", { ascending: false });
  if (error) throw new Error(error.message);
  return (data ?? []) as Lead[];
}

/** phone -> owning agent email, used to badge conversations with their lead owner. */
export async function fetchLeadOwners(): Promise<Record<string, Lead>> {
  const leads = await fetchLeads();
  const map: Record<string, Lead> = {};
  for (const lead of leads) map[lead.phone] = lead;
  return map;
}

const HEADER_ALIASES: Record<string, keyof LeadInput> = {
  name: "name",
  lead: "name",
  "lead name": "name",
  "customer name": "name",
  "full name": "name",
  phone: "phone",
  "phone number": "phone",
  mobile: "phone",
  "mobile number": "phone",
  number: "phone",
  whatsapp: "phone",
  agent: "agent_email",
  "agent email": "agent_email",
  "agent email id": "agent_email",
  email: "agent_email",
  "assigned to": "agent_email",
  owner: "agent_email",
  source: "source",
};

/** Maps loose spreadsheet headers onto lead fields. */
export function rowsToLeads(rows: Record<string, unknown>[]): LeadInput[] {
  const out: LeadInput[] = [];
  for (const row of rows) {
    const lead: LeadInput = { phone: "" };
    for (const [rawKey, rawValue] of Object.entries(row)) {
      const key = HEADER_ALIASES[rawKey.trim().toLowerCase()];
      if (!key) continue;
      const value = String(rawValue ?? "").trim();
      if (!value) continue;
      if (key === "phone") lead.phone = cleanPhone(value);
      else lead[key] = value;
    }
    if (lead.phone) out.push(lead);
  }
  return out;
}

/** Minimal CSV parser handling quoted values. */
export function parseCsv(text: string): Record<string, string>[] {
  const rows: string[][] = [];
  let cell = "";
  let row: string[] = [];
  let quoted = false;

  for (let i = 0; i < text.length; i += 1) {
    const char = text[i];
    if (quoted) {
      if (char === '"' && text[i + 1] === '"') {
        cell += '"';
        i += 1;
      } else if (char === '"') quoted = false;
      else cell += char;
      continue;
    }
    if (char === '"') quoted = true;
    else if (char === "," || char === "\t") {
      row.push(cell);
      cell = "";
    } else if (char === "\n") {
      row.push(cell);
      rows.push(row);
      row = [];
      cell = "";
    } else if (char !== "\r") cell += char;
  }
  row.push(cell);
  rows.push(row);

  const cleaned = rows.filter((r) => r.some((c) => c.trim() !== ""));
  if (cleaned.length < 2) return [];
  const header = cleaned[0]!.map((h) => h.trim());
  return cleaned.slice(1).map((line) => {
    const record: Record<string, string> = {};
    header.forEach((key, index) => {
      record[key] = (line[index] ?? "").trim();
    });
    return record;
  });
}

/** Reads a CSV or Excel file into lead rows. */
export async function readLeadFile(file: File): Promise<LeadInput[]> {
  const isExcel = /\.(xlsx|xls)$/i.test(file.name);
  if (!isExcel) return rowsToLeads(parseCsv(await file.text()));

  const XLSX = await import("xlsx");
  const workbook = XLSX.read(await file.arrayBuffer(), { type: "array" });
  const sheetName = workbook.SheetNames[0];
  if (!sheetName) return [];
  const sheet = workbook.Sheets[sheetName];
  if (!sheet) return [];
  const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(sheet, { defval: "" });
  return rowsToLeads(rows);
}
