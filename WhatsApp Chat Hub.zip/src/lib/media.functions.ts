import { createServerFn } from "@tanstack/react-start";

import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export interface UploadMediaPayload {
  fileName: string;
  contentType: string;
  /** Base64 encoded file contents (no data: prefix). */
  dataBase64: string;
}

const YEAR_SECONDS = 60 * 60 * 24 * 365;

/** Uploads an agent attachment and returns a link the WhatsApp provider can fetch. */
export const uploadChatMedia = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: UploadMediaPayload) => {
    if (!input?.fileName?.trim()) throw new Error("A file name is required");
    if (!input?.dataBase64) throw new Error("The file could not be read");
    return input;
  })
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const bytes = Uint8Array.from(atob(data.dataBase64), (c) => c.charCodeAt(0));
    if (bytes.byteLength > 25 * 1024 * 1024) {
      throw new Error("Attachments must be 25 MB or smaller");
    }

    const safeName = data.fileName.replace(/[^\w.\-]+/g, "_").slice(-80);
    const path = `outgoing/${Date.now()}-${Math.random().toString(36).slice(2, 8)}-${safeName}`;

    const { error } = await supabaseAdmin.storage
      .from("wa-media")
      .upload(path, bytes, { contentType: data.contentType || "application/octet-stream" });
    if (error) throw new Error(error.message);

    const { data: signed, error: signError } = await supabaseAdmin.storage
      .from("wa-media")
      .createSignedUrl(path, YEAR_SECONDS);
    if (signError || !signed?.signedUrl) {
      throw new Error(signError?.message ?? "Could not create a link for the attachment");
    }

    return { url: signed.signedUrl, fileName: safeName };
  });
