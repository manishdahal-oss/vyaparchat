import { createServerFn } from "@tanstack/react-start";

import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/* eslint-disable @typescript-eslint/no-explicit-any */

export interface StaffMember {
  userId: string;
  email: string;
  status: "pending" | "approved" | "revoked";
  role: "admin" | "agent" | null;
  requestedAt: string;
  decidedAt: string | null;
  lastSignInAt: string | null;
}

async function assertAdmin(context: { supabase: any; userId: string }) {
  const { data, error } = await context.supabase.rpc("has_role", {
    _user_id: context.userId,
    _role: "admin",
  });
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Only admins can manage team access");
}

/** Public: request a portal account. Creates the login and leaves it pending admin approval. */
export const requestAccess = createServerFn({ method: "POST" })
  .inputValidator((input: { email: string; password: string }) => {
    const email = String(input?.email ?? "").trim().toLowerCase();
    const password = String(input?.password ?? "");
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) throw new Error("Enter a valid work email");
    if (password.length < 8) throw new Error("Password must be at least 8 characters");
    return { email, password };
  })
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: created, error } = await supabaseAdmin.auth.admin.createUser({
      email: data.email,
      password: data.password,
      email_confirm: true,
    });

    if (error || !created?.user) {
      const message = error?.message ?? "Could not create the account";
      if (/already/i.test(message))
        throw new Error("An account with this email already exists. Ask an admin to approve it.");
      throw new Error(message);
    }

    const { error: accessError } = await supabaseAdmin.from("staff_access").insert({
      user_id: created.user.id,
      email: data.email,
      status: "pending",
    });
    if (accessError) throw new Error(accessError.message);

    return { ok: true, email: data.email };
  });

/** Signed-in user: own approval status. */
export const myAccess = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data } = await (context as any).supabase
      .from("staff_access")
      .select("status")
      .eq("user_id", (context as any).userId)
      .maybeSingle();
    return { status: (data?.status ?? "approved") as StaffMember["status"] };
  });

/** Admin-only: full team list with roles and approval status. */
export const listTeam = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context as never);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: users } = await supabaseAdmin.auth.admin.listUsers({ page: 1, perPage: 500 });
    const { data: roles } = await supabaseAdmin.from("user_roles").select("user_id, role");
    const { data: access } = await supabaseAdmin.from("staff_access").select("*");

    const roleFor = new Map((roles ?? []).map((r: any) => [r.user_id, r.role]));
    const accessFor = new Map((access ?? []).map((a: any) => [a.user_id, a]));

    const members: StaffMember[] = (users?.users ?? []).map((u: any) => {
      const row = accessFor.get(u.id);
      return {
        userId: u.id,
        email: u.email ?? "",
        status: (row?.status ?? "approved") as StaffMember["status"],
        role: (roleFor.get(u.id) ?? null) as StaffMember["role"],
        requestedAt: row?.requested_at ?? u.created_at,
        decidedAt: row?.decided_at ?? null,
        lastSignInAt: u.last_sign_in_at ?? null,
      };
    });

    members.sort((a, b) => {
      const rank = (m: StaffMember) => (m.status === "pending" ? 0 : m.status === "approved" ? 1 : 2);
      return rank(a) - rank(b) || a.email.localeCompare(b.email);
    });

    return members;
  });

/** Admin-only: approve (grants agent access) or revoke a staff account. */
export const setStaffStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { userId: string; status: "approved" | "revoked" }) => {
    if (!input?.userId) throw new Error("User is required");
    if (input.status !== "approved" && input.status !== "revoked")
      throw new Error("Invalid status");
    return input;
  })
  .handler(async ({ data, context }) => {
    await assertAdmin(context as never);
    if (data.userId === (context as any).userId)
      throw new Error("You cannot change your own access");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: user } = await supabaseAdmin.auth.admin.getUserById(data.userId);
    const email = user?.user?.email ?? "";

    const { error } = await supabaseAdmin.from("staff_access").upsert(
      {
        user_id: data.userId,
        email,
        status: data.status,
        decided_at: new Date().toISOString(),
        decided_by: (context as any).userId,
      },
      { onConflict: "user_id" },
    );
    if (error) throw new Error(error.message);

    const { data: roles } = await supabaseAdmin
      .from("user_roles")
      .select("role")
      .eq("user_id", data.userId);
    const isAdminUser = (roles ?? []).some((r: any) => r.role === "admin");

    if (data.status === "approved") {
      if (!roles?.length) {
        const { error: roleError } = await supabaseAdmin
          .from("user_roles")
          .insert({ user_id: data.userId, role: "agent" });
        if (roleError) throw new Error(roleError.message);
      }
    } else if (!isAdminUser) {
      await supabaseAdmin.from("user_roles").delete().eq("user_id", data.userId);
    }

    return { ok: true };
  });
