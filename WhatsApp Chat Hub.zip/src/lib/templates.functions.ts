import { createServerFn } from "@tanstack/react-start";

import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

import type { ProviderTemplate } from "./templates.server";

/* eslint-disable @typescript-eslint/no-explicit-any */
function countVars(text: string) {
  const found = new Set<string>();
  for (const match of text.matchAll(/\{\{\s*(\d+)\s*\}\}/g)) found.add(match[1] as string);
  return found.size;
}

function rowToTemplate(row: any): ProviderTemplate {
  const bodyText = String(row?.body_text ?? "");
  return {
    name: String(row?.name ?? ""),
    language: String(row?.language ?? "en"),
    status: String(row?.status ?? "approved").toUpperCase(),
    category: row?.category ? String(row.category) : null,
    headerText: row?.header_text ? String(row.header_text) : null,
    bodyText,
    footerText: row?.footer_text ? String(row.footer_text) : null,
    buttons: Array.isArray(row?.buttons)
      ? row.buttons.map((b: any) => String(b?.text ?? b?.type ?? b ?? "")).filter(Boolean)
      : [],
    variableCount: row?.variable_count ?? countVars(bodyText),
  };
}

async function assertAdmin(context: { supabase: any; userId: string }) {
  const { data, error } = await context.supabase.rpc("has_role", {
    _user_id: context.userId,
    _role: "admin",
  });
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Only admins can manage templates");
}

/** Templates available for pushing — admin-maintained, inactive ones excluded. */
export const listProviderTemplates = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("templates")
      .select("*")
      .neq("status", "inactive")
      .order("name", { ascending: true });

    const templates = (data ?? []).map(rowToTemplate).filter((t: ProviderTemplate) => t.name);
    return {
      templates,
      error: templates.length ? null : (error?.message ?? "No active templates yet"),
      notice: templates.length ? null : "Add templates from the Templates page.",
      source: "database" as const,
    };
  });

/** Full template list including inactive ones (admin management view). */
export const listAllTemplates = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context as never);
    const { data, error } = await context.supabase
      .from("templates")
      .select("*")
      .order("name", { ascending: true });
    if (error) throw new Error(error.message);
    return (data ?? []) as any[];
  });

export interface TemplateInput {
  id?: string | null;
  name: string;
  language?: string;
  category?: string | null;
  headerText?: string | null;
  bodyText: string;
  footerText?: string | null;
  buttons?: string[];
  status?: string;
}

export const saveTemplate = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: TemplateInput) => {
    if (!input?.name?.trim()) throw new Error("Template name is required");
    if (!input?.bodyText?.trim()) throw new Error("Template body text is required");
    return input;
  })
  .handler(async ({ data, context }) => {
    await assertAdmin(context as never);
    const row = {
      name: data.name.trim(),
      language: data.language?.trim() || "en",
      category: data.category?.trim() || null,
      header_type: data.headerText?.trim() ? "text" : "none",
      header_text: data.headerText?.trim() || null,
      body_text: data.bodyText.trim(),
      footer_text: data.footerText?.trim() || null,
      buttons: (data.buttons ?? []).filter(Boolean).map((text) => ({ type: "QUICK_REPLY", text })),
      variable_count: countVars(data.bodyText),
      status: data.status?.trim() || "approved",
    };

    if (data.id) {
      const { error } = await context.supabase.from("templates").update(row).eq("id", data.id);
      if (error) throw new Error(error.message);
      return { ok: true, id: data.id };
    }

    const { data: created, error } = await context.supabase
      .from("templates")
      .insert(row)
      .select("id")
      .single();
    if (error) throw new Error(error.message);
    return { ok: true, id: created?.id as string };
  });

export const setTemplateStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { id: string; status: string }) => {
    if (!input?.id) throw new Error("Template id is required");
    return input;
  })
  .handler(async ({ data, context }) => {
    await assertAdmin(context as never);
    const { error } = await context.supabase
      .from("templates")
      .update({ status: data.status })
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const deleteTemplate = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { id: string }) => {
    if (!input?.id) throw new Error("Template id is required");
    return input;
  })
  .handler(async ({ data, context }) => {
    await assertAdmin(context as never);
    const { error } = await context.supabase.from("templates").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });
