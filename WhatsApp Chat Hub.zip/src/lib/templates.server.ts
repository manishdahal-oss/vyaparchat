/**
 * Server-only helper that lists WhatsApp templates from the provider.
 *
 *   WHATSAPP_TEMPLATES_API_URL  optional, defaults to the TimesPanel list endpoint
 *   WHATSAPP_API_TOKEN          same auth token used for sending
 *   WHATSAPP_AUTH_HEADER        header name, default "Authorization"
 *   WHATSAPP_AUTH_SCHEME        "none"/"raw" sends the token as-is
 */
import { readConfig } from "./whatsapp.server";

const DEFAULT_TEMPLATES_URL = "https://asyncmsg.integration.timespanel.in/wa/v1/templates";

export interface ProviderTemplate {
  name: string;
  language: string;
  status: string;
  category: string | null;
  headerText: string | null;
  bodyText: string;
  footerText: string | null;
  buttons: string[];
  variableCount: number;
}

/* eslint-disable @typescript-eslint/no-explicit-any */
function countVars(text: string) {
  const found = new Set<string>();
  for (const match of text.matchAll(/\{\{\s*(\d+)\s*\}\}/g)) found.add(match[1] as string);
  return found.size;
}

function toTemplate(raw: any): ProviderTemplate | null {
  const name = raw?.name ?? raw?.templateName ?? raw?.elementName;
  if (!name) return null;
  const components: any[] = Array.isArray(raw?.components) ? raw.components : [];
  const find = (type: string) =>
    components.find((c) => String(c?.type ?? "").toUpperCase() === type);

  const header = find("HEADER");
  const body = find("BODY");
  const footer = find("FOOTER");
  const buttonsComp = find("BUTTONS");

  const bodyText = String(body?.text ?? raw?.body ?? raw?.bodyText ?? "");

  return {
    name: String(name),
    language: String(raw?.language ?? raw?.languageCode ?? raw?.language?.code ?? "en"),
    status: String(raw?.status ?? "UNKNOWN").toUpperCase(),
    category: raw?.category ? String(raw.category) : null,
    headerText: header?.text ? String(header.text) : null,
    bodyText,
    footerText: footer?.text ? String(footer.text) : null,
    buttons: Array.isArray(buttonsComp?.buttons)
      ? buttonsComp.buttons.map((b: any) => String(b?.text ?? b?.type ?? "")).filter(Boolean)
      : [],
    variableCount: countVars(bodyText),
  };
}

function pickList(payload: any): any[] {
  if (Array.isArray(payload)) return payload;
  for (const key of ["res_json", "data", "templates", "result", "resJson"]) {
    const value = payload?.[key];
    if (Array.isArray(value)) return value;
    if (value && Array.isArray(value?.data)) return value.data;
  }
  return [];
}

export async function fetchProviderTemplates(): Promise<{
  templates: ProviderTemplate[];
  error: string | null;
}> {
  const cfg = readConfig();
  const url = process.env["WHATSAPP_TEMPLATES_API_URL"] ?? DEFAULT_TEMPLATES_URL;

  const headers: Record<string, string> = { "Content-Type": "application/json" };
  if (cfg.token) {
    const scheme = /^(none|raw)$/i.test(cfg.authScheme.trim()) ? "" : cfg.authScheme.trim();
    headers[cfg.authHeader] = scheme ? `${scheme} ${cfg.token}` : cfg.token;
  }

  try {
    const res = await fetch(url, { method: "GET", headers });
    const text = await res.text();
    let parsed: any = text;
    try {
      parsed = JSON.parse(text);
    } catch {
      /* keep raw */
    }
    if (!res.ok) {
      return { templates: [], error: `Template list API responded with ${res.status}` };
    }
    const templates = pickList(parsed)
      .map(toTemplate)
      .filter((t): t is ProviderTemplate => Boolean(t))
      .sort((a, b) => a.name.localeCompare(b.name));
    if (!templates.length) {
      return { templates: [], error: "No templates returned by the provider" };
    }
    return { templates, error: null };
  } catch (err) {
    return {
      templates: [],
      error: err instanceof Error ? err.message : "Network error fetching templates",
    };
  }
}
