import { createServerFn } from "@tanstack/react-start";

import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

import { callSendApi, normalizePhone } from "./whatsapp.server";

export interface PushMessagePayload {
  phone: string;
  messageType?: string;
  bodyParam?: string;
  params?: string[];
  language?: string;
}

export const pushVyaparMessage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: PushMessagePayload) => {
    if (!input || typeof input.phone !== "string" || !normalizePhone(input.phone)) {
      throw new Error("A valid customer phone number is required");
    }
    return input;
  })
  .handler(async ({ data, context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const phone = normalizePhone(data.phone);
    const templateName = data.messageType?.trim() || "sales_with_extra_details";
    const language = data.language?.trim() || "en";
    const params = (data.params ?? (data.bodyParam ? [data.bodyParam] : []))
      .map((p) => String(p ?? "").trim())
      .filter((p) => p.length > 0);
    const now = new Date().toISOString();

    const { data: convo } = await supabaseAdmin
      .from("conversations")
      .select("id")
      .eq("phone", phone)
      .maybeSingle();

    let conversationId = convo?.id;
    if (!conversationId) {
      const { data: created, error } = await supabaseAdmin
        .from("conversations")
        .insert({ phone })
        .select("id")
        .single();
      if (error || !created) throw new Error(error?.message ?? "Could not create conversation");
      conversationId = created.id;
    }

    // Self-assign: whoever pushes owns the lead (unless it is already owned).
    const senderEmail =
      typeof (context as { claims?: { email?: string } }).claims?.email === "string"
        ? (context as { claims: { email: string } }).claims.email.trim().toLowerCase()
        : null;

    if (senderEmail) {
      const { data: roles } = await supabaseAdmin
        .from("user_roles")
        .select("role")
        .eq("user_id", (context as { userId: string }).userId);
      const isAdmin = (roles ?? []).some((r) => r.role === "admin");

      if (!isAdmin) {
        const { data: lead } = await supabaseAdmin
          .from("leads")
          .select("id, agent_email")
          .eq("phone", phone)
          .maybeSingle();

        if (!lead) {
          await supabaseAdmin.from("leads").insert({
            phone,
            agent_email: senderEmail,
            source: "self-assigned via push",
          });
        } else if (!lead.agent_email) {
          await supabaseAdmin
            .from("leads")
            .update({ agent_email: senderEmail, updated_at: now })
            .eq("id", lead.id);
        }
      }
    }

    const preview = `[template] ${templateName}`;

    const { data: pending, error: insertError } = await supabaseAdmin
      .from("messages")
      .insert({
        conversation_id: conversationId,
        phone,
        direction: "outgoing",
        message_type: "template",
        body: preview,
        template_name: templateName,
        status: "pending",
      })
      .select("id")
      .single();
    if (insertError || !pending) {
      throw new Error(insertError?.message ?? "Could not save message");
    }

    const result = await callSendApi("template", {
      to: phone,
      templateName,
      language,
      ...(params.length ? { params } : {}),
    });

    await supabaseAdmin
      .from("messages")
      .update({
        status: result.ok ? "sent" : "failed",
        wa_message_id: result.messageId ?? null,
        trace_id: result.traceId ?? null,
        error: result.error ?? null,
      })
      .eq("id", pending.id);

    if (result.ok) {
      await supabaseAdmin
        .from("conversations")
        .update({ last_message: preview, last_message_at: now, updated_at: now })
        .eq("id", conversationId);
    }

    return {
      ok: result.ok,
      status: result.status,
      recipient: phone,
      messageType: templateName,
      response:
        typeof result.response === "string"
          ? result.response.slice(0, 500)
          : JSON.stringify(result.response ?? {}).slice(0, 500),
      error: result.error ?? null,
    };
  });
