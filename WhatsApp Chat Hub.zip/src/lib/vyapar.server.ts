const PUSH_API_URL = "https://vyaparapp.in/api/ns/message/cv/send-message";

/** Vyapar expects the local 10-digit number, not the E.164 form. */
export function toLocalNumber(phone: string): string {
  const digits = phone.replace(/\D/g, "");
  return digits.length > 10 ? digits.slice(-10) : digits;
}

export interface PushResult {
  ok: boolean;
  status: number;
  body: string;
  messageId: string | null;
}

export async function callVyaparPush(input: {
  recipient: string;
  messageType: string;
  agentEmail: string;
  deviceId?: string;
}): Promise<PushResult> {
  const body = {
    messages: [
      {
        message: {
          messageType: input.messageType,
          recipient: input.recipient,
          deviceId: input.deviceId ?? "DATATEAM",
          platform: "WEB",
          ackQueueType: "STANDARD",
          templateFilterParams: {},
        },
        payload: { agent_email: input.agentEmail },
        byPassValidation: true,
      },
    ],
  };

  try {
    const response = await fetch(PUSH_API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const text = await response.text();
    let messageId: string | null = null;
    let apiError: string | null = null;
    try {
      const parsed = JSON.parse(text) as Record<string, unknown>;
      messageId =
        (parsed["messageId"] as string | undefined) ??
        (parsed["requestId"] as string | undefined) ??
        null;
      // The API answers 200 even when a message is rejected; surface that error.
      const results = parsed["resultList"];
      if (Array.isArray(results)) {
        for (const entry of results) {
          const message = (entry as Record<string, unknown> | null)?.["errorMessage"];
          if (typeof message === "string" && message.trim()) {
            apiError = message;
            break;
          }
        }
      }
      const topLevel = parsed["errorMessage"];
      if (!apiError && typeof topLevel === "string" && topLevel.trim()) apiError = topLevel;
    } catch {
      messageId = null;
    }
    return {
      ok: response.ok && !apiError,
      status: response.status,
      body: apiError ?? text.slice(0, 500),
      messageId,
    };
  } catch (error) {
    return { ok: false, status: 0, body: (error as Error).message, messageId: null };
  }
}
