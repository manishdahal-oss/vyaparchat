import { createServerFn } from "@tanstack/react-start";

import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

import { callSendApi, normalizePhone, readConfig } from "./whatsapp.server";

export interface SendMessagePayload {
  phone: string;
  kind: "text" | "template" | "media";
  text?: string;
  templateName?: string;
  language?: string;
  params?: string[];
  mediaUrl?: string;
  mediaKind?: "image" | "video" | "document" | "audio";
  fileName?: string;
}

export const getWhatsAppStatus = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async () => {
  const cfg = readConfig();
  return {
    sendApiConfigured: Boolean(cfg.url),
    authConfigured: Boolean(cfg.token),
    webhookSecretConfigured: Boolean(process.env["WHATSAPP_WEBHOOK_SECRET"]),
  };
});

export const sendWhatsAppMessage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: SendMessagePayload) => {
    if (!input || typeof input.phone !== "string" || !normalizePhone(input.phone)) {
      throw new Error("A valid customer phone number is required");
    }
    if (input.kind === "text" && !input.text?.trim()) {
      throw new Error("Message text is required");
    }
    if (input.kind === "template" && !input.templateName) {
      throw new Error("A template must be selected");
    }
    if (input.kind === "media" && !input.mediaUrl) {
      throw new Error("An attachment link is required");
    }
    return input;
  })
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const phone = normalizePhone(data.phone);
    const now = new Date().toISOString();

    const { data: convo } = await supabaseAdmin
      .from("conversations")
      .select("id")
      .eq("phone", phone)
      .maybeSingle();

    let conversationId = convo?.id;
    if (!conversationId) {
      const { data: created, error } = await supabaseAdmin
        .from("conversations")
        .insert({ phone })
        .select("id")
        .single();
      if (error || !created) throw new Error(error?.message ?? "Could not create conversation");
      conversationId = created.id;
    }

    const preview =
      data.kind === "text"
        ? (data.text ?? "")
        : data.kind === "media"
          ? (data.text?.trim() || `[${data.mediaKind ?? "document"}] ${data.fileName ?? "attachment"}`)
          : `[template] ${data.templateName ?? ""}`;

    const { data: pending, error: insertError } = await supabaseAdmin
      .from("messages")
      .insert({
        conversation_id: conversationId,
        phone,
        direction: "outgoing",
        message_type: data.kind === "media" ? (data.mediaKind ?? "document") : data.kind,
        body: preview,
        media_url: data.mediaUrl ?? null,
        template_name: data.templateName ?? null,
        status: "pending",
      })
      .select("id")
      .single();
    if (insertError || !pending) {
      throw new Error(insertError?.message ?? "Could not save message");
    }

    const sendInput: Parameters<typeof callSendApi>[1] = { to: phone };
    if (data.text) sendInput.text = data.text;
    if (data.templateName) sendInput.templateName = data.templateName;
    if (data.language) sendInput.language = data.language;
    if (data.params) sendInput.params = data.params;
    if (data.mediaUrl) sendInput.mediaUrl = data.mediaUrl;
    if (data.mediaKind) sendInput.mediaKind = data.mediaKind;
    if (data.fileName) sendInput.fileName = data.fileName;

    const result = await callSendApi(data.kind, sendInput);

    await supabaseAdmin
      .from("messages")
      .update({
        status: result.ok ? "sent" : "failed",
        wa_message_id: result.messageId ?? null,
        trace_id: result.traceId ?? null,
        error: result.error ?? null,
      })
      .eq("id", pending.id);

    if (result.ok) {
      await supabaseAdmin
        .from("conversations")
        .update({ last_message: preview, last_message_at: now, updated_at: now })
        .eq("id", conversationId);
    }

    return {
      ok: result.ok,
      messageId: pending.id,
      error: result.error ?? null,
      status: result.status,
    };
  });

export const markConversationRead = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { conversationId: string }) => {
    if (!input?.conversationId) throw new Error("conversationId is required");
    return input;
  })
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin
      .from("conversations")
      .update({ unread_count: 0 })
      .eq("id", data.conversationId);
    return { ok: true };
  });
