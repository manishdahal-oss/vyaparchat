/**
 * Server-only helpers for the WhatsApp integration.
 *
 * Everything here is configurable through environment secrets so the
 * Send Message API (endpoint, auth, request shape) can be supplied later
 * without touching application code.
 *
 *   WHATSAPP_SEND_API_URL     required, e.g. https://api.timesportal.com/v1/messages
 *   WHATSAPP_API_TOKEN        auth token / api key
 *   WHATSAPP_AUTH_HEADER      header name, default "Authorization"
 *   WHATSAPP_AUTH_SCHEME      prefix for the token, default "Bearer" ("" for raw)
 *   WHATSAPP_SENDER_ID        optional sender / from number / channel id
 *   WHATSAPP_EXTRA_HEADERS    optional JSON object of extra headers
 *   WHATSAPP_TEXT_PAYLOAD     optional JSON template for text sends
 *   WHATSAPP_TEMPLATE_PAYLOAD optional JSON template for template sends
 *   WHATSAPP_WEBHOOK_SECRET   optional shared secret for the Times webhook
 *
 * Payload templates may use these placeholders anywhere inside strings:
 *   {{to}} {{text}} {{sender}} {{template_name}} {{language}}
 * and the special token "{{params}}" as a whole string value, which is
 * replaced by the array of template variables.
 */

export type SendKind = "text" | "template" | "media";

export type MediaKind = "image" | "video" | "document" | "audio";

export interface SendInput {
  to: string;
  text?: string;
  templateName?: string;
  language?: string;
  params?: string[];
  mediaUrl?: string;
  mediaKind?: MediaKind;
  fileName?: string;
}

export interface SendResult {
  ok: boolean;
  messageId?: string;
  traceId?: string;
  status: number;
  response: unknown;
  error?: string;
}

export function readConfig() {
  return {
    url: process.env["WHATSAPP_SEND_API_URL"] ?? "",
    token: process.env["WHATSAPP_API_TOKEN"] ?? "",
    authHeader: process.env["WHATSAPP_AUTH_HEADER"] ?? "Authorization",
    authScheme: process.env["WHATSAPP_AUTH_SCHEME"] ?? "Bearer",
    sender: process.env["WHATSAPP_SENDER_ID"] ?? "",
    extraHeaders: process.env["WHATSAPP_EXTRA_HEADERS"] ?? "",
    textPayload: process.env["WHATSAPP_TEXT_PAYLOAD"] ?? "",
    templatePayload: process.env["WHATSAPP_TEMPLATE_PAYLOAD"] ?? "",
  };
}

function parseJson<T>(raw: string): T | null {
  if (!raw.trim()) return null;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return null;
  }
}

function interpolate(node: unknown, vars: Record<string, string>, params: string[]): unknown {
  if (typeof node === "string") {
    if (node.trim() === "{{params}}") return params;
    return node.replace(/\{\{(\w+)\}\}/g, (_m, key: string) => vars[key] ?? "");
  }
  if (Array.isArray(node)) return node.map((n) => interpolate(n, vars, params));
  if (node && typeof node === "object") {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(node as Record<string, unknown>)) {
      out[k] = interpolate(v, vars, params);
    }
    return out;
  }
  return node;
}

function defaultPayload(kind: SendKind, input: SendInput) {
  if (kind === "media") {
    const mediaKind = input.mediaKind ?? "document";
    const media: Record<string, string> = { link: input.mediaUrl ?? "" };
    if (input.text?.trim() && mediaKind !== "audio") media["caption"] = input.text.trim();
    if (mediaKind === "document" && input.fileName) media["filename"] = input.fileName;
    return {
      messaging_product: "whatsapp",
      recipient_type: "individual",
      to: input.to,
      type: mediaKind,
      [mediaKind]: media,
    };
  }
  if (kind === "text") {
    return {
      messaging_product: "whatsapp",
      recipient_type: "individual",
      to: input.to,
      type: "text",
      text: { body: input.text ?? "" },
    };
  }
  const components: unknown[] = [];
  if (input.mediaUrl) {
    components.push({
      type: "header",
      parameters: [{ type: "image", image: { link: input.mediaUrl } }],
    });
  }
  if (input.params?.length) {
    components.push({
      type: "body",
      parameters: input.params.map((t) => ({ type: "text", text: t })),
    });
  }
  return {
    messaging_product: "whatsapp",
    recipient_type: "individual",
    to: input.to,
    type: "template",
    template: {
      name: input.templateName,
      language: { code: input.language ?? "en" },
      ...(components.length ? { components } : {}),
    },
  };
}

function pickMessageId(res: unknown): string | undefined {
  const seen = new Set<unknown>();
  const keys = ["messageId", "message_id", "id", "mid", "wamid", "messageid"];
  const walk = (node: unknown): string | undefined => {
    if (!node || typeof node !== "object" || seen.has(node)) return undefined;
    seen.add(node);
    if (Array.isArray(node)) {
      for (const n of node) {
        const found = walk(n);
        if (found) return found;
      }
      return undefined;
    }
    const obj = node as Record<string, unknown>;
    for (const k of keys) {
      const v = obj[k];
      if (typeof v === "string" && v.length > 0) return v;
    }
    for (const v of Object.values(obj)) {
      const found = walk(v);
      if (found) return found;
    }
    return undefined;
  };
  return walk(res);
}

function pickErrorMessage(res: unknown): string | undefined {
  if (!res || typeof res !== "object") return undefined;
  const seen = new Set<unknown>();
  const keys = ["errorMessage", "error_message", "errorMsg", "error", "errors", "message"];
  const walk = (node: unknown): string | undefined => {
    if (!node || typeof node !== "object" || seen.has(node)) return undefined;
    seen.add(node);
    if (Array.isArray(node)) {
      for (const n of node) {
        const found = walk(n);
        if (found) return found;
      }
      return undefined;
    }
    const obj = node as Record<string, unknown>;
    const status = obj["status"];
    for (const k of keys) {
      const v = obj[k];
      if (k === "message" && typeof status === "string" && /success|sent|ok/i.test(status)) continue;
      if (typeof v === "string" && v.trim()) return v;
    }
    for (const v of Object.values(obj)) {
      const found = walk(v);
      if (found) return found;
    }
    return undefined;
  };
  return walk(res);
}

function getHeader(headers: Headers, ...names: string[]): string | undefined {
  for (const name of names) {
    const value = headers.get(name) ?? headers.get(name.toLowerCase());
    if (value) return value;
  }
  return undefined;
}

function extractHeaderMessageId(headers: Headers): string | undefined {
  return getHeader(
    headers,
    "x-message-id",
    "message-id",
    "x-wa-message-id",
    "x-request-message-id",
    "x-msg-id",
  );
}

function extractHeaderTraceId(headers: Headers): string | undefined {
  return getHeader(
    headers,
    "x-trace-id",
    "trace-id",
    "x-request-id",
    "request-id",
    "x-correlation-id",
    "x-correlationid",
    "x-amzn-trace-id",
    "x-b3-traceid",
    "traceparent",
  );
}




export async function callSendApi(kind: SendKind, input: SendInput): Promise<SendResult> {
  const cfg = readConfig();
  if (!cfg.url) {
    return {
      ok: false,
      status: 0,
      response: null,
      error:
        "The Send Message API is not configured yet. Add WHATSAPP_SEND_API_URL (and auth) to enable sending.",
    };
  }

  const vars: Record<string, string> = {
    to: input.to,
    text: input.text ?? "",
    sender: cfg.sender,
    template_name: input.templateName ?? "",
    language: input.language ?? "en",
    media_url: input.mediaUrl ?? "",
  };

  const override =
    kind === "media" ? null : parseJson<unknown>(kind === "text" ? cfg.textPayload : cfg.templatePayload);
  const body = override
    ? interpolate(override, vars, input.params ?? [])
    : defaultPayload(kind, input);

  const headers: Record<string, string> = { "Content-Type": "application/json" };
  if (cfg.token) {
    // "none"/"raw"/"" send the token as-is (TimesPanel expects a bare Authorization value).
    const scheme = /^(none|raw)$/i.test(cfg.authScheme.trim()) ? "" : cfg.authScheme.trim();
    headers[cfg.authHeader] = scheme ? `${scheme} ${cfg.token}` : cfg.token;
  }
  const extra = parseJson<Record<string, string>>(cfg.extraHeaders);
  if (extra) Object.assign(headers, extra);

  try {
    const res = await fetch(cfg.url, {
      method: "POST",
      headers,
      body: JSON.stringify(body),
    });
    const raw = await res.text();
    let parsed: unknown = raw;
    try {
      parsed = JSON.parse(raw);
    } catch {
      /* keep raw text */
    }
    // Some gateways (TimesPanel included) return HTTP 200 with an error body.
    const bodyError = pickErrorMessage(parsed);
    const ok = res.ok && !bodyError;
    const headerMessageId = extractHeaderMessageId(res.headers);
    const headerTraceId = extractHeaderTraceId(res.headers);
    const bodyMessageId = ok ? pickMessageId(parsed) : undefined;
    const messageId = headerMessageId ?? bodyMessageId;
    const result: SendResult = { ok, status: res.status, response: parsed };
    if (!ok) result.error = bodyError ?? `Send API responded with ${res.status}`;
    if (messageId) result.messageId = messageId;
    if (headerTraceId) result.traceId = headerTraceId;
    return result;

  } catch (err) {
    return {
      ok: false,
      status: 0,
      response: null,
      error: err instanceof Error ? err.message : "Network error calling the Send Message API",
    };
  }
}

/** Best-effort extraction of an inbound message from an unknown webhook payload. */
export interface InboundMessage {
  phone: string;
  name?: string;
  text: string;
  messageId?: string;
  type: string;
  mediaUrl?: string;
}

/* eslint-disable @typescript-eslint/no-explicit-any */
const g = (obj: unknown, ...keys: string[]): any => {
  let cur: any = obj;
  for (const k of keys) {
    if (cur == null) return undefined;
    cur = cur[k];
  }
  return cur;
};

const first = (...vals: unknown[]): any => vals.find((v) => v !== undefined && v !== null && v !== "");

function extractMedia(m: unknown): string | undefined {
  for (const key of ["document", "image", "video", "audio", "voice", "sticker", "file", "media", "attachment"]) {
    const node = g(m, key);
    if (!node) continue;
    if (typeof node === "string" && /^https?:\/\//.test(node)) return node;
    const url = first(g(node, "link"), g(node, "url"), g(node, "mediaUrl"), g(node, "media_url"), g(node, "downloadUrl"));
    if (url) return String(url);
  }
  const flat = first(g(m, "mediaUrl"), g(m, "media_url"), g(m, "fileUrl"), g(m, "file_url"), g(m, "url"), g(m, "link"));
  return flat ? String(flat) : undefined;
}

export function parseInbound(payload: unknown): InboundMessage | null {
  if (!payload || typeof payload !== "object") return null;
  const root = payload as Record<string, unknown>;

  // Meta Cloud API / Times Portal (entry -> changes -> value -> messages)
  const value = g(root, "entry", "0", "changes", "0", "value");
  const m = g(value, "messages", "0");
  if (m) {
    const out: InboundMessage = {
      phone: normalizePhone(g(m, "from") ?? ""),
      text: extractText(m),
      type: g(m, "type") ?? "text",
    };
    const name = g(value, "contacts", "0", "profile", "name");
    if (name) out.name = String(name);
    if (g(m, "id")) out.messageId = String(g(m, "id"));
    const media = extractMedia(m);
    if (media) out.mediaUrl = media;
    const fileName = first(
      g(m, "document", "filename"),
      g(m, "document", "file_name"),
      g(m, "document", "caption"),
    );
    if (!out.text && fileName) out.text = String(fileName);
    return out;
  }

  // Flat payloads: { from | mobile | msisdn | waNumber, text | message | body }
  const phone = normalizePhone(
    first(
      g(root, "from"),
      g(root, "mobile"),
      g(root, "msisdn"),
      g(root, "waNumber"),
      g(root, "phone"),
      g(root, "sender"),
    ) ?? "",
  );
  if (!phone) return null;
  const rawText = g(root, "text");
  const rawMsg = g(root, "message");
  const text = first(
    typeof rawText === "string" ? rawText : g(rawText, "body"),
    typeof rawMsg === "string" ? rawMsg : g(rawMsg, "text"),
    g(root, "body"),
    g(root, "content"),
  );
  const out: InboundMessage = {
    phone,
    text: String(text ?? ""),
    type: first(g(root, "type"), g(root, "messageType")) ?? "text",
  };
  const name = first(g(root, "name"), g(root, "profileName"), g(root, "senderName"));
  if (name) out.name = String(name);
  const id = first(g(root, "messageId"), g(root, "message_id"), g(root, "id"));
  if (id) out.messageId = String(id);
  const media = extractMedia(root) ?? extractMedia(rawMsg);
  if (media) out.mediaUrl = media;
  const fileName = first(
    g(root, "fileName"),
    g(root, "file_name"),
    g(root, "document", "filename"),
  );
  if (!out.text && fileName) out.text = String(fileName);
  return out;
}

function extractText(m: unknown): string {
  return String(
    first(
      g(m, "text", "body"),
      g(m, "button", "text"),
      g(m, "interactive", "button_reply", "title"),
      g(m, "interactive", "list_reply", "title"),
      g(m, "image", "caption"),
      g(m, "document", "caption"),
    ) ?? "",
  );
}


export function normalizePhone(raw: string): string {
  return String(raw ?? "").replace(/[^\d]/g, "");
}
