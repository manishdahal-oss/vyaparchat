import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { ArrowLeft, Clock3, MessageCircle, UserRound } from "lucide-react";

import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";

import { Composer } from "@/components/chat/composer";
import { ConversationList } from "@/components/chat/conversation-list";
import {
  PushMessageDialog,
  type PushLogEntry,
  type PushRequest,
} from "@/components/chat/push-message-dialog";
import { MessageThread } from "@/components/chat/message-thread";
import { AssignAgentSelect } from "@/components/assign-agent-select";
import { PortalHeader } from "@/components/portal-header";
import { Button } from "@/components/ui/button";
import { Toaster } from "@/components/ui/sonner";
import { useStaff } from "@/hooks/use-staff";
import { supabase } from "@/integrations/supabase/client";
import {
  displayName,
  fetchConversations,
  fetchMessages,
  fetchTemplates,
  formatCountdown,
  formatPhone,
  initials,
  renderTemplate,
  windowStatus,
  type Conversation,
  type Template,
} from "@/lib/chat-data";
import { fileToBase64, mediaKindFor } from "@/lib/attachments";
import { fetchLeadOwners } from "@/lib/leads";
import { uploadChatMedia } from "@/lib/media.functions";
import { pushVyaparMessage } from "@/lib/vyapar.functions";
import {
  getWhatsAppStatus,
  markConversationRead,
  sendWhatsAppMessage,
} from "@/lib/whatsapp.functions";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/")({
  head: () => ({
    meta: [
      { title: "WhatsApp Customer Chat Portal | Agent Inbox" },
      {
        name: "description",
        content:
          "Handle WhatsApp customer conversations in real time: recent chats, 24-hour window status, free-text replies and approved template messages.",
      },
      { property: "og:title", content: "WhatsApp Customer Chat Portal" },
      {
        property: "og:description",
        content:
          "A WhatsApp-style agent inbox with live incoming messages, 24-hour session tracking and template sending.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ChatPortal,
});

function ChatPortal() {
  const queryClient = useQueryClient();
  const staff = useStaff();
  const [activeId, setActiveId] = useState<string | null>(null);
  const [tick, setTick] = useState(0);
  const [pushLog, setPushLog] = useState<PushLogEntry[]>([]);
  const [uploading, setUploading] = useState(false);

  const upload = useServerFn(uploadChatMedia);
  const send = useServerFn(sendWhatsAppMessage);
  const markRead = useServerFn(markConversationRead);
  const status = useServerFn(getWhatsAppStatus);
  const push = useServerFn(pushVyaparMessage);

  const conversationsQuery = useQuery({
    queryKey: ["conversations"],
    queryFn: fetchConversations,
  });
  const templatesQuery = useQuery({ queryKey: ["templates"], queryFn: fetchTemplates });
  const ownersQuery = useQuery({ queryKey: ["lead-owners"], queryFn: fetchLeadOwners });
  const configQuery = useQuery({ queryKey: ["wa-status"], queryFn: () => status({}) });

  const owners = ownersQuery.data ?? {};
  const conversations = useMemo(() => conversationsQuery.data ?? [], [conversationsQuery.data]);
  const active = conversations.find((c) => c.id === activeId) ?? null;

  const messagesQuery = useQuery({
    queryKey: ["messages", activeId],
    queryFn: () => fetchMessages(activeId as string),
    enabled: Boolean(activeId),
  });

  // Realtime: incoming webhook writes + outgoing status updates.
  useEffect(() => {
    const channel = supabase
      .channel("wa-portal")
      .on("postgres_changes", { event: "*", schema: "public", table: "messages" }, () => {
        void queryClient.invalidateQueries({ queryKey: ["messages"] });
        void queryClient.invalidateQueries({ queryKey: ["conversations"] });
      })
      .on("postgres_changes", { event: "*", schema: "public", table: "conversations" }, () => {
        void queryClient.invalidateQueries({ queryKey: ["conversations"] });
      })
      .subscribe();

    return () => {
      void supabase.removeChannel(channel);
    };
  }, [queryClient]);

  // Keeps the 24-hour countdown fresh.
  useEffect(() => {
    const id = setInterval(() => setTick((t) => t + 1), 30000);
    return () => clearInterval(id);
  }, []);
  void tick;

  const openConversation = async (conversation: Conversation) => {
    setActiveId(conversation.id);
    if (conversation.unread_count > 0) {
      await markRead({ data: { conversationId: conversation.id } });
      void queryClient.invalidateQueries({ queryKey: ["conversations"] });
    }
  };

  const sendMutation = useMutation({
    mutationFn: async (payload: Parameters<typeof send>[0]["data"]) => send({ data: payload }),
    onSuccess: (result) => {
      if (!result.ok) toast.error(result.error ?? "The message could not be delivered.");
    },
    onError: (error: Error) => toast.error(error.message),
    onSettled: () => {
      void queryClient.invalidateQueries({ queryKey: ["messages"] });
      void queryClient.invalidateQueries({ queryKey: ["conversations"] });
    },
  });


  const pushMutation = useMutation({
    mutationFn: async (payload: PushRequest) => push({ data: payload }),
    onSuccess: (result, variables) => {
      void queryClient.invalidateQueries({ queryKey: ["messages"] });
      void queryClient.invalidateQueries({ queryKey: ["conversations"] });
      setPushLog((prev) => [
        {
          id: `${Date.now()}`,
          at: new Date().toLocaleTimeString(),
          phone: variables.phone,
          messageType: variables.messageType,
          ok: result.ok,
          status: result.status,
          detail: result.ok ? (result.response || "Message pushed.") : (result.error ?? "Unknown error"),
        },
        ...prev,
      ]);
      if (result.ok) toast.success(`${variables.messageType} pushed to ${variables.phone}.`);
      else toast.error(result.error ?? "The push message could not be triggered.");
    },
    onError: (error: Error, variables) => {
      setPushLog((prev) => [
        {
          id: `${Date.now()}`,
          at: new Date().toLocaleTimeString(),
          phone: variables.phone,
          messageType: variables.messageType,
          ok: false,
          status: 0,
          detail: error.message,
        },
        ...prev,
      ]);
      toast.error(error.message);
    },
  });


  const { active: windowOpen, msLeft } = windowStatus(active);

  return (
    <div className="flex h-screen flex-col bg-background">
      <Toaster position="top-center" />
      <PortalHeader
        email={staff.email}
        isAdmin={staff.isAdmin}
        sendApiConfigured={configQuery.data?.sendApiConfigured}
      />

      <div className="flex min-h-0 flex-1">
        <aside
          className={cn(
            "w-full border-r border-border md:w-80 lg:w-96",
            active ? "hidden md:block" : "block",
          )}
        >
          <ConversationList
            conversations={conversations}
            owners={owners}
            showOwner={staff.isAdmin}
            activeId={activeId}
            loading={conversationsQuery.isLoading}
            onSelect={(conversation) => void openConversation(conversation)}
            action={
              (
              <PushMessageDialog
                sending={pushMutation.isPending}
                log={pushLog}
                onPush={async (request) => {
                  await pushMutation.mutateAsync(request).catch(() => undefined);
                }}
              />
              )
            }
          />
        </aside>

        <main className={cn("min-w-0 flex-1 flex-col", active ? "flex" : "hidden md:flex")}>
          {!active ? (
            <div className="chat-canvas flex flex-1 items-center justify-center p-8 text-center">
              <div className="max-w-sm">
                <MessageCircle className="mx-auto size-10 text-brand" />
                <h2 className="mt-3 text-base font-semibold">Select a conversation</h2>
                <p className="mt-1 text-sm text-muted-foreground">
                  Incoming customer replies land here instantly. Pick a chat on the left to view the
                  history and reply.
                </p>
              </div>
            </div>
          ) : (
            <>
              <div className="flex items-center gap-3 border-b border-border bg-card px-4 py-3 sm:px-6">
                <Button
                  variant="ghost"
                  size="icon"
                  className="md:hidden"
                  onClick={() => setActiveId(null)}
                  aria-label="Back to conversations"
                >
                  <ArrowLeft className="size-4" />
                </Button>
                <span className="flex size-10 items-center justify-center rounded-full bg-brand/15 text-sm font-semibold text-brand-deep">
                  {initials(active)}
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-semibold">{displayName(active)}</p>
                  <p className="flex flex-wrap items-center gap-1.5 text-xs text-muted-foreground">
                    {formatPhone(active.phone)}
                    <span
                      className={cn(
                        "inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px]",
                        owners[active.phone]?.agent_email
                          ? "bg-brand/10 text-brand-deep"
                          : "bg-warning/20 text-warning-foreground",
                      )}
                    >
                      <UserRound className="size-3" />
                      {owners[active.phone]?.agent_email ?? "Unassigned lead"}
                    </span>
                  </p>
                </div>
                {staff.isAdmin ? (
                  <AssignAgentSelect
                    phone={active.phone}
                    name={active.name}
                    value={owners[active.phone]?.agent_email ?? null}
                    size="sm"
                    className="hidden w-52 sm:flex"
                  />
                ) : null}
                <span
                  className={cn(
                    "inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-[11px] font-medium",
                    windowOpen
                      ? "bg-success/15 text-success"
                      : "bg-warning/20 text-warning-foreground",
                  )}
                >
                  <Clock3 className="size-3.5" />
                  {windowOpen
                    ? `Active - free text allowed · ${formatCountdown(msLeft)}`
                    : "Window expired - template required"}
                </span>
              </div>


              <MessageThread
                messages={messagesQuery.data ?? []}
                loading={messagesQuery.isLoading}
                error={messagesQuery.error ? (messagesQuery.error as Error).message : null}
              />

              <Composer
                windowOpen={windowOpen}
                templates={templatesQuery.data ?? []}
                sending={sendMutation.isPending || uploading}
                onSendAttachment={async (file, caption) => {
                  setUploading(true);
                  try {
                    const dataBase64 = await fileToBase64(file);
                    const uploaded = await upload({
                      data: {
                        fileName: file.name,
                        contentType: file.type || "application/octet-stream",
                        dataBase64,
                      },
                    });
                    await sendMutation.mutateAsync({
                      phone: active.phone,
                      kind: "media",
                      mediaUrl: uploaded.url,
                      mediaKind: mediaKindFor(file.type, file.name),
                      fileName: uploaded.fileName,
                      ...(caption ? { text: caption } : {}),
                    });
                  } catch (error) {
                    toast.error(error instanceof Error ? error.message : "Upload failed");
                  } finally {
                    setUploading(false);
                  }
                }}
                onSendText={async (text) => {
                  await sendMutation.mutateAsync({ phone: active.phone, kind: "text", text });
                }}
                onSendTemplate={async (template: Template, params: string[]) => {
                  await sendMutation.mutateAsync({
                    phone: active.phone,
                    kind: "template",
                    templateName: template.name,
                    language: template.language,
                    params,
                    text: renderTemplate(template, params),
                    ...(template.header_media_url ? { mediaUrl: template.header_media_url } : {}),
                  });
                }}
              />
            </>
          )}
        </main>
      </div>
    </div>
  );
}
