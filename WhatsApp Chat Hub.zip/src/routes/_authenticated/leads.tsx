import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { FileSpreadsheet, Loader2, Trash2, TriangleAlert, UserPlus, Users } from "lucide-react";
import { useRef, useState } from "react";
import { toast } from "sonner";

import { AssignAgentSelect } from "@/components/assign-agent-select";
import { PortalHeader } from "@/components/portal-header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Toaster } from "@/components/ui/sonner";
import { useStaff } from "@/hooks/use-staff";
import { cleanPhone, fetchLeads, readLeadFile, type LeadInput } from "@/lib/leads";
import { deleteLead, listAgents, upsertLeads } from "@/lib/leads.functions";

export const Route = createFileRoute("/_authenticated/leads")({
  head: () => ({
    meta: [
      { title: "Leads & Agent Mapping | Customer Chat Portal" },
      {
        name: "description",
        content:
          "Upload leads one by one or from CSV/Excel and map every customer phone number to the agent who owns the conversation.",
      },
      { property: "og:title", content: "Leads & Agent Mapping" },
      {
        property: "og:description",
        content:
          "Assign customer phone numbers to agents so every WhatsApp chat routes to its lead owner.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: LeadsPage,
});

const UNASSIGNED = "__unassigned__";

function LeadsPage() {
  const staff = useStaff();
  const queryClient = useQueryClient();
  const fileRef = useRef<HTMLInputElement>(null);

  const upsert = useServerFn(upsertLeads);
  const remove = useServerFn(deleteLead);
  const agentsFn = useServerFn(listAgents);

  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [agentEmail, setAgentEmail] = useState("");
  const [log, setLog] = useState<string[]>([]);
  const [page, setPage] = useState(1);

  const leadsQuery = useQuery({ queryKey: ["leads"], queryFn: fetchLeads });
  const agentsQuery = useQuery({
    queryKey: ["agents"],
    queryFn: () => agentsFn({}),
    enabled: staff.isAdmin,
  });

  const leads = leadsQuery.data ?? [];
  const unassigned = leads.filter((l) => !l.agent_email).length;
  const PAGE_SIZE = 10;
  const pageCount = Math.max(1, Math.ceil(leads.length / PAGE_SIZE));
  const currentPage = Math.min(page, pageCount);
  const pagedLeads = leads.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);

  const saveMutation = useMutation({
    mutationFn: async (rows: LeadInput[]) => upsert({ data: { leads: rows } }),
    onSuccess: (result, rows) => {
      void queryClient.invalidateQueries({ queryKey: ["leads"] });
      void queryClient.invalidateQueries({ queryKey: ["conversations"] });
      const stamp = new Date().toLocaleTimeString();
      setLog((prev) => [
        `${stamp} · Saved ${result.saved} of ${rows.length} lead(s)` +
          (result.unassigned ? `, ${result.unassigned} without an agent` : "") +
          (result.skipped.length ? ` · skipped: ${result.skipped.join("; ")}` : ""),
        ...prev,
      ]);
      if (result.saved) toast.success(`${result.saved} lead(s) saved.`);
      else toast.error("No leads were saved.");
    },
    onError: (error: Error) => {
      setLog((prev) => [`${new Date().toLocaleTimeString()} · Error: ${error.message}`, ...prev]);
      toast.error(error.message);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => remove({ data: { id } }),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ["leads"] });
      toast.success("Lead removed.");
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const onAddSingle = async (event: React.FormEvent) => {
    event.preventDefault();
    const digits = cleanPhone(phone);
    if (digits.length < 8) {
      toast.error("Enter a valid phone number with country code, e.g. 919611272070.");
      return;
    }
    await saveMutation
      .mutateAsync([{ name, phone: digits, agent_email: agentEmail || null, source: "manual" }])
      .catch(() => undefined);
    setName("");
    setPhone("");
  };

  const onFile = async (file: File) => {
    try {
      const rows = await readLeadFile(file);
      if (!rows.length) {
        toast.error("No rows found. Expected columns: name, phone, agent email.");
        return;
      }
      await saveMutation
        .mutateAsync(rows.map((r) => ({ ...r, source: r.source ?? file.name })))
        .catch(() => undefined);
    } catch (error) {
      toast.error((error as Error).message);
    } finally {
      if (fileRef.current) fileRef.current.value = "";
    }
  };

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <Toaster position="top-center" />
      <PortalHeader email={staff.email} isAdmin={staff.isAdmin} />

      <main className="mx-auto w-full max-w-6xl flex-1 space-y-6 p-4 sm:p-6">
        <div>
          <h2 className="text-lg font-semibold tracking-tight">Leads & agent mapping</h2>
          <p className="text-sm text-muted-foreground">
            Every customer number is owned by one agent. Chats only reach the mapped agent —
            unmapped numbers stay with the admin.
          </p>
        </div>

        {staff.isAdmin ? (
          <div className="grid gap-4 lg:grid-cols-2">
            <section className="rounded-xl border border-border bg-card p-4">
              <h3 className="flex items-center gap-2 text-sm font-semibold">
                <UserPlus className="size-4 text-brand" /> Add one lead
              </h3>
              <form className="mt-3 space-y-3" onSubmit={onAddSingle}>
                <div className="space-y-1.5">
                  <Label htmlFor="lead-name">Customer name</Label>
                  <Input
                    id="lead-name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Ramesh Kumar"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="lead-phone">Phone number (with country code)</Label>
                  <Input
                    id="lead-phone"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="919611272070"
                    inputMode="numeric"
                    required
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="lead-agent">Map to agent</Label>
                  <Select
                    value={agentEmail || UNASSIGNED}
                    onValueChange={(value) => setAgentEmail(value === UNASSIGNED ? "" : value)}
                  >
                    <SelectTrigger id="lead-agent">
                      <SelectValue placeholder="Select agent" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value={UNASSIGNED}>Unassigned (admin only)</SelectItem>
                      {(agentsQuery.data ?? []).map((agent) => (
                        <SelectItem key={agent.email} value={agent.email}>
                          {agent.email} · {agent.role}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <Button type="submit" disabled={saveMutation.isPending} className="w-full">
                  {saveMutation.isPending ? <Loader2 className="size-4 animate-spin" /> : null}
                  Save lead
                </Button>
              </form>
            </section>

            <section className="rounded-xl border border-border bg-card p-4">
              <h3 className="flex items-center gap-2 text-sm font-semibold">
                <FileSpreadsheet className="size-4 text-brand" /> Bulk upload (CSV or Excel)
              </h3>
              <p className="mt-2 text-xs text-muted-foreground">
                Columns accepted: <code>name</code>, <code>phone</code>, <code>agent email</code>.
                Existing numbers are updated, not duplicated.
              </p>
              <input
                ref={fileRef}
                type="file"
                accept=".csv,.tsv,.txt,.xlsx,.xls"
                className="mt-3 block w-full text-xs file:mr-3 file:rounded-md file:border-0 file:bg-secondary file:px-3 file:py-2 file:text-xs file:font-medium"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) void onFile(file);
                }}
              />
              <a
                className="mt-3 inline-block text-xs text-brand underline"
                download="leads-template.csv"
                href={`data:text/csv;charset=utf-8,${encodeURIComponent(
                  "name,phone,agent email\nRamesh Kumar,919611272070,agent1@vyaparapp.in\n",
                )}`}
              >
                Download sample CSV
              </a>

              {log.length ? (
                <ul className="scroll-slim mt-3 max-h-32 space-y-1 overflow-y-auto rounded-md bg-secondary/60 p-2 text-[11px] text-muted-foreground">
                  {log.map((entry, index) => (
                    <li key={index}>{entry}</li>
                  ))}
                </ul>
              ) : null}
            </section>
          </div>
        ) : (
          <p className="rounded-xl border border-border bg-card p-4 text-sm text-muted-foreground">
            You are viewing the leads assigned to <strong>{staff.email}</strong>. Ask an admin to
            map more numbers to you.
          </p>
        )}

        <section className="rounded-xl border border-border bg-card">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-border px-4 py-3">
            <h3 className="flex items-center gap-2 text-sm font-semibold">
              <Users className="size-4 text-brand" /> {leads.length} lead(s)
            </h3>
            {staff.isAdmin && unassigned > 0 ? (
              <span className="inline-flex items-center gap-1.5 rounded-full bg-warning/20 px-2.5 py-1 text-[11px] font-medium text-warning-foreground">
                <TriangleAlert className="size-3.5" /> {unassigned} unmapped — visible to admin only
              </span>
            ) : null}
          </div>

          {leadsQuery.isLoading ? (
            <div className="space-y-2 p-4">
              {[0, 1, 2].map((i) => (
                <Skeleton key={i} className="h-9 w-full" />
              ))}
            </div>
          ) : leads.length === 0 ? (
            <p className="p-6 text-sm text-muted-foreground">No leads yet.</p>
          ) : (
            <div className="scroll-slim max-h-[26rem] overflow-auto">
              <table className="w-full text-left text-sm">
                <thead className="sticky top-0 bg-secondary/80 text-xs text-muted-foreground">
                  <tr>
                    <th className="px-4 py-2 font-medium">Name</th>
                    <th className="px-4 py-2 font-medium">Phone</th>
                    <th className="px-4 py-2 font-medium">Agent</th>
                    <th className="px-4 py-2 font-medium">Source</th>
                    {staff.isAdmin ? <th className="px-4 py-2" /> : null}
                  </tr>
                </thead>
                <tbody>
                  {pagedLeads.map((lead) => (
                    <tr key={lead.id} className="border-t border-border">
                      <td className="px-4 py-2">{lead.name ?? "—"}</td>
                      <td className="px-4 py-2 tabular-nums">+{lead.phone}</td>
                      <td className="px-4 py-2">
                        {staff.isAdmin ? (
                          <AssignAgentSelect
                            phone={lead.phone}
                            name={lead.name}
                            value={lead.agent_email}
                            size="sm"
                            className="w-56"
                          />
                        ) : lead.agent_email ? (
                          <span className="rounded-full bg-brand/10 px-2 py-0.5 text-xs text-brand-deep">
                            {lead.agent_email}
                          </span>
                        ) : (
                          <span className="rounded-full bg-warning/20 px-2 py-0.5 text-xs text-warning-foreground">
                            Unassigned
                          </span>
                        )}
                      </td>
                      <td className="px-4 py-2 text-xs text-muted-foreground">
                        {lead.source ?? "—"}
                      </td>
                      {staff.isAdmin ? (
                        <td className="px-4 py-2 text-right">
                          <Button
                            variant="ghost"
                            size="icon"
                            aria-label={`Delete lead ${lead.phone}`}
                            onClick={() => deleteMutation.mutate(lead.id)}
                          >
                            <Trash2 className="size-4 text-destructive" />
                          </Button>
                        </td>
                      ) : null}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {leads.length > PAGE_SIZE ? (
            <div className="flex flex-wrap items-center justify-between gap-2 border-t border-border px-4 py-3">
              <p className="text-xs text-muted-foreground">
                Showing {(currentPage - 1) * PAGE_SIZE + 1}–
                {Math.min(currentPage * PAGE_SIZE, leads.length)} of {leads.length}
              </p>
              <div className="flex flex-wrap items-center gap-1">
                <Button
                  variant="outline"
                  size="sm"
                  disabled={currentPage === 1}
                  onClick={() => setPage(currentPage - 1)}
                >
                  Prev
                </Button>
                {Array.from({ length: pageCount }, (_, i) => i + 1).map((n) => (
                  <Button
                    key={n}
                    variant={n === currentPage ? "default" : "outline"}
                    size="sm"
                    aria-current={n === currentPage ? "page" : undefined}
                    onClick={() => setPage(n)}
                  >
                    {n}
                  </Button>
                ))}
                <Button
                  variant="outline"
                  size="sm"
                  disabled={currentPage === pageCount}
                  onClick={() => setPage(currentPage + 1)}
                >
                  Next
                </Button>
              </div>
            </div>
          ) : null}
        </section>
      </main>
    </div>
  );
}
