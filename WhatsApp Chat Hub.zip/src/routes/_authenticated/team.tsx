import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { CheckCircle2, Clock3, Loader2, ShieldCheck, ShieldX, Users } from "lucide-react";
import { Toaster, toast } from "sonner";

import { PortalHeader } from "@/components/portal-header";
import { Button } from "@/components/ui/button";
import { useStaff } from "@/hooks/use-staff";
import { listTeam, setStaffStatus, type StaffMember } from "@/lib/staff.functions";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/team")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Team Access | WhatsApp Chat Portal" },
      {
        name: "description",
        content:
          "Approve new agent logins, review pending access requests and revoke portal access for the WhatsApp chat team.",
      },
      { property: "og:title", content: "Team Access | WhatsApp Chat Portal" },
      {
        property: "og:description",
        content: "Admin tools to approve or revoke agent access to the WhatsApp chat portal.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: TeamPage,
});

function statusBadge(status: StaffMember["status"]) {
  if (status === "approved")
    return { label: "Approved", className: "bg-success/15 text-success", icon: CheckCircle2 };
  if (status === "pending")
    return {
      label: "Pending approval",
      className: "bg-warning/20 text-warning-foreground",
      icon: Clock3,
    };
  return { label: "Revoked", className: "bg-destructive/10 text-destructive", icon: ShieldX };
}

function TeamPage() {
  const staff = useStaff();
  const queryClient = useQueryClient();
  const fetchTeam = useServerFn(listTeam);
  const changeStatus = useServerFn(setStaffStatus);

  const teamQuery = useQuery({
    queryKey: ["team"],
    queryFn: () => fetchTeam(),
    enabled: staff.isAdmin,
  });

  const mutation = useMutation({
    mutationFn: (input: { userId: string; status: "approved" | "revoked" }) =>
      changeStatus({ data: input }),
    onSuccess: (_res, input) => {
      toast.success(input.status === "approved" ? "Access approved" : "Access revoked");
      void queryClient.invalidateQueries({ queryKey: ["team"] });
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const members = teamQuery.data ?? [];
  const pending = members.filter((m) => m.status === "pending");

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <Toaster position="top-center" />
      <PortalHeader email={staff.email} isAdmin={staff.isAdmin} />

      <main className="mx-auto w-full max-w-4xl flex-1 p-4 sm:p-6">
        {!staff.isAdmin ? (
          <div className="rounded-xl border border-border bg-card p-6 text-sm text-muted-foreground">
            Team management is available to admins only.
          </div>
        ) : (
          <>
            <div className="mb-4 flex items-center gap-2">
              <Users className="size-5 text-brand" />
              <div>
                <h2 className="text-base font-semibold">Team access</h2>
                <p className="text-xs text-muted-foreground">
                  New sign-ups stay locked out until you approve them. Approved accounts get agent
                  access by default.
                </p>
              </div>
            </div>

            {pending.length ? (
              <div className="mb-4 rounded-lg border border-warning/40 bg-warning/10 px-3 py-2 text-xs text-warning-foreground">
                {pending.length} account{pending.length > 1 ? "s" : ""} pending your approval.
              </div>
            ) : null}

            <div className="overflow-hidden rounded-xl border border-border bg-card">
              {teamQuery.isLoading ? (
                <div className="flex items-center gap-2 p-6 text-sm text-muted-foreground">
                  <Loader2 className="size-4 animate-spin" /> Loading team…
                </div>
              ) : teamQuery.error ? (
                <p className="p-6 text-sm text-destructive">{(teamQuery.error as Error).message}</p>
              ) : !members.length ? (
                <p className="p-6 text-sm text-muted-foreground">No accounts yet.</p>
              ) : (
                <ul className="divide-y divide-border">
                  {members.map((member) => {
                    const badge = statusBadge(member.status);
                    const Icon = badge.icon;
                    const isSelf = member.email === staff.email;
                    return (
                      <li
                        key={member.userId}
                        className="flex flex-wrap items-center justify-between gap-3 px-4 py-3"
                      >
                        <div className="min-w-0">
                          <p className="truncate text-sm font-medium">{member.email}</p>
                          <p className="mt-0.5 flex flex-wrap items-center gap-1.5 text-[11px] text-muted-foreground">
                            <span
                              className={cn(
                                "inline-flex items-center gap-1 rounded-full px-2 py-0.5",
                                badge.className,
                              )}
                            >
                              <Icon className="size-3" />
                              {badge.label}
                            </span>
                            <span className="inline-flex items-center gap-1 rounded-full bg-secondary px-2 py-0.5">
                              <ShieldCheck className="size-3" />
                              {member.role ?? "no role"}
                            </span>
                            {member.lastSignInAt ? (
                              <span>
                                last sign in {new Date(member.lastSignInAt).toLocaleString()}
                              </span>
                            ) : (
                              <span>never signed in</span>
                            )}
                          </p>
                        </div>

                        <div className="flex items-center gap-2">
                          {member.status !== "approved" ? (
                            <Button
                              size="sm"
                              disabled={mutation.isPending || isSelf}
                              onClick={() =>
                                mutation.mutate({ userId: member.userId, status: "approved" })
                              }
                            >
                              Approve
                            </Button>
                          ) : null}
                          {member.status !== "revoked" ? (
                            <Button
                              size="sm"
                              variant="outline"
                              disabled={mutation.isPending || isSelf}
                              onClick={() =>
                                mutation.mutate({ userId: member.userId, status: "revoked" })
                              }
                            >
                              Revoke access
                            </Button>
                          ) : null}
                        </div>
                      </li>
                    );
                  })}
                </ul>
              )}
            </div>
          </>
        )}
      </main>
    </div>
  );
}
