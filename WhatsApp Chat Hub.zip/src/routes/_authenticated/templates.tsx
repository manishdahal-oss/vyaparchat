import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createFileRoute } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { Ban, CheckCircle2, FilePlus2, Loader2, Trash2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

import { PortalHeader } from "@/components/portal-header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Toaster } from "@/components/ui/sonner";
import { useStaff } from "@/hooks/use-staff";
import {
  deleteTemplate,
  listAllTemplates,
  saveTemplate,
  setTemplateStatus,
} from "@/lib/templates.functions";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/_authenticated/templates")({
  head: () => ({
    meta: [
      { title: "WhatsApp Templates | Customer Chat Portal" },
      {
        name: "description",
        content:
          "Admins add, deactivate and delete the approved WhatsApp templates agents can push to customers.",
      },
      { property: "og:title", content: "WhatsApp Templates" },
      {
        property: "og:description",
        content: "Manage the approved WhatsApp templates used to start customer conversations.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: TemplatesPage,
});

/* eslint-disable @typescript-eslint/no-explicit-any */
function TemplatesPage() {
  const staff = useStaff();
  const queryClient = useQueryClient();

  const listFn = useServerFn(listAllTemplates);
  const saveFn = useServerFn(saveTemplate);
  const statusFn = useServerFn(setTemplateStatus);
  const deleteFn = useServerFn(deleteTemplate);

  const [name, setName] = useState("");
  const [language, setLanguage] = useState("en");
  const [category, setCategory] = useState("");
  const [headerText, setHeaderText] = useState("");
  const [bodyText, setBodyText] = useState("");
  const [footerText, setFooterText] = useState("");
  const [buttons, setButtons] = useState("");
  const [showForm, setShowForm] = useState(false);

  const templatesQuery = useQuery({
    queryKey: ["all-templates"],
    queryFn: () => listFn({}),
    enabled: staff.isAdmin,
  });

  const invalidate = () => {
    void queryClient.invalidateQueries({ queryKey: ["all-templates"] });
    void queryClient.invalidateQueries({ queryKey: ["provider-templates"] });
  };

  const save = useMutation({
    mutationFn: async () =>
      saveFn({
        data: {
          name,
          language,
          category: category || null,
          headerText: headerText || null,
          bodyText,
          footerText: footerText || null,
          buttons: buttons
            .split(",")
            .map((b) => b.trim())
            .filter(Boolean),
        },
      }),
    onSuccess: () => {
      invalidate();
      toast.success("Template saved.");
      setName("");
      setCategory("");
      setHeaderText("");
      setBodyText("");
      setFooterText("");
      setButtons("");
      setShowForm(false);
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const toggle = useMutation({
    mutationFn: async (vars: { id: string; status: string }) => statusFn({ data: vars }),
    onSuccess: () => {
      invalidate();
      toast.success("Template status updated.");
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const remove = useMutation({
    mutationFn: async (id: string) => deleteFn({ data: { id } }),
    onSuccess: () => {
      invalidate();
      toast.success("Template deleted.");
    },
    onError: (error: Error) => toast.error(error.message),
  });

  const templates = (templatesQuery.data ?? []) as any[];

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <Toaster position="top-center" />
      <PortalHeader email={staff.email} isAdmin={staff.isAdmin} />

      <main className="mx-auto w-full max-w-5xl flex-1 space-y-6 p-4 sm:p-6">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <h2 className="text-lg font-semibold tracking-tight">WhatsApp templates</h2>
            <p className="text-sm text-muted-foreground">
              These templates power the Push message dialog. Inactive templates stay saved but are
              hidden from agents.
            </p>
          </div>
          {staff.isAdmin ? (
            <Button className="gap-1.5" onClick={() => setShowForm((v) => !v)}>
              <FilePlus2 className="size-4" />
              {showForm ? "Close" : "Add template"}
            </Button>
          ) : null}
        </div>

        {!staff.loading && !staff.isAdmin ? (
          <p className="rounded-xl border border-border bg-card p-4 text-sm text-muted-foreground">
            Only admins can manage templates.
          </p>
        ) : null}

        {staff.isAdmin && showForm ? (
          <section className="rounded-xl border border-border bg-card p-4">
            <form
              className="grid gap-3 sm:grid-cols-2"
              onSubmit={(event) => {
                event.preventDefault();
                save.mutate();
              }}
            >
              <div className="space-y-1.5">
                <Label htmlFor="t-name">Template name</Label>
                <Input
                  id="t-name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="sales_with_extra_details"
                  required
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="t-lang">Language code</Label>
                <Input id="t-lang" value={language} onChange={(e) => setLanguage(e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="t-cat">Category</Label>
                <Input
                  id="t-cat"
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  placeholder="MARKETING"
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="t-header">Header text (optional)</Label>
                <Input
                  id="t-header"
                  value={headerText}
                  onChange={(e) => setHeaderText(e.target.value)}
                />
              </div>
              <div className="space-y-1.5 sm:col-span-2">
                <Label htmlFor="t-body">Body text — use {`{{1}}`} for variables</Label>
                <textarea
                  id="t-body"
                  value={bodyText}
                  onChange={(e) => setBodyText(e.target.value)}
                  required
                  rows={4}
                  className="w-full rounded-md border border-input bg-background p-2 text-sm"
                  placeholder="Hi {{1}}, your payment of {{2}} is due."
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="t-footer">Footer text (optional)</Label>
                <Input
                  id="t-footer"
                  value={footerText}
                  onChange={(e) => setFooterText(e.target.value)}
                />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="t-buttons">Buttons (comma separated)</Label>
                <Input
                  id="t-buttons"
                  value={buttons}
                  onChange={(e) => setButtons(e.target.value)}
                  placeholder="Call now, Know more"
                />
              </div>
              <div className="sm:col-span-2">
                <Button type="submit" disabled={save.isPending} className="gap-1.5">
                  {save.isPending ? <Loader2 className="size-4 animate-spin" /> : null}
                  Save template
                </Button>
              </div>
            </form>
          </section>
        ) : null}

        {staff.isAdmin ? (
          <section className="rounded-xl border border-border bg-card">
            {templatesQuery.isLoading ? (
              <div className="space-y-2 p-4">
                <Skeleton className="h-12 w-full" />
                <Skeleton className="h-12 w-full" />
              </div>
            ) : templates.length === 0 ? (
              <p className="p-6 text-center text-sm text-muted-foreground">
                No templates yet. Add your first one.
              </p>
            ) : (
              <ul className="divide-y divide-border">
                {templates.map((template) => {
                  const inactive = String(template.status).toLowerCase() === "inactive";
                  return (
                    <li key={template.id} className="flex flex-wrap gap-3 p-4">
                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="text-sm font-semibold">{template.name}</span>
                          <span
                            className={cn(
                              "rounded-full px-2 py-0.5 text-[11px]",
                              inactive
                                ? "bg-muted text-muted-foreground"
                                : "bg-brand/10 text-brand-deep",
                            )}
                          >
                            {inactive ? "Inactive" : template.status}
                          </span>
                          <span className="text-[11px] text-muted-foreground">
                            {template.language}
                            {template.category ? ` · ${template.category}` : ""} ·{" "}
                            {template.variable_count} variable
                            {template.variable_count === 1 ? "" : "s"}
                          </span>
                        </div>
                        {template.header_text ? (
                          <p className="mt-1 text-xs font-semibold">{template.header_text}</p>
                        ) : null}
                        <p className="mt-1 text-sm whitespace-pre-wrap">{template.body_text}</p>
                        {template.footer_text ? (
                          <p className="mt-1 text-[11px] text-muted-foreground">
                            {template.footer_text}
                          </p>
                        ) : null}
                      </div>
                      <div className="flex items-start gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          className="gap-1.5"
                          disabled={toggle.isPending}
                          onClick={() =>
                            toggle.mutate({
                              id: template.id,
                              status: inactive ? "approved" : "inactive",
                            })
                          }
                        >
                          {inactive ? (
                            <CheckCircle2 className="size-3.5" />
                          ) : (
                            <Ban className="size-3.5" />
                          )}
                          {inactive ? "Activate" : "Mark inactive"}
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="gap-1.5 text-destructive hover:text-destructive"
                          disabled={remove.isPending}
                          onClick={() => {
                            if (confirm(`Delete template "${template.name}"?`))
                              remove.mutate(template.id);
                          }}
                        >
                          <Trash2 className="size-3.5" />
                          Delete
                        </Button>
                      </div>
                    </li>
                  );
                })}
              </ul>
            )}
          </section>
        ) : null}
      </main>
    </div>
  );
}
