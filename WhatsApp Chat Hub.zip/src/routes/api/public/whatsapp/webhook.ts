import { createFileRoute } from "@tanstack/react-router";

import { parseInbound } from "@/lib/whatsapp.server";

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

export const Route = createFileRoute("/api/public/whatsapp/webhook")({
  server: {
    handlers: {
      // Verification handshake (hub.challenge style) + health check
      GET: async ({ request }) => {
        const url = new URL(request.url);
        const challenge = url.searchParams.get("hub.challenge");
        const verifyToken = url.searchParams.get("hub.verify_token");
        const expected = process.env["WHATSAPP_WEBHOOK_SECRET"];
        if (challenge) {
          if (expected && verifyToken !== expected) {
            return new Response("Forbidden", { status: 403 });
          }
          return new Response(challenge, { status: 200 });
        }
        return json({ ok: true, endpoint: "whatsapp-webhook" });
      },

      POST: async ({ request }) => {
        const expected = process.env["WHATSAPP_WEBHOOK_SECRET"];
        if (expected) {
          const url = new URL(request.url);
          const provided =
            request.headers.get("x-webhook-secret") ??
            request.headers.get("x-times-signature") ??
            url.searchParams.get("secret") ??
            "";
          if (provided !== expected) {
            return json({ ok: false, error: "Invalid webhook secret" }, 401);
          }
        }

        let payload: unknown;
        try {
          payload = await request.json();
        } catch {
          return json({ ok: false, error: "Invalid JSON body" }, 400);
        }

        const inbound = parseInbound(payload);

        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

        await supabaseAdmin.from("webhook_events").insert({
          method: "POST",
          parsed: Boolean(inbound?.phone),
          note: inbound?.phone
            ? `inbound from ${inbound.phone}`
            : "payload did not match a known inbound message shape",
          payload: payload as never,
        });

        if (!inbound?.phone) {
          // Status callbacks and other events are acknowledged without storing.
          return json({ ok: true, ignored: true });
        }

        const now = new Date().toISOString();

        const { data: existing } = await supabaseAdmin
          .from("conversations")
          .select("id, unread_count, name")
          .eq("phone", inbound.phone)
          .maybeSingle();

        let conversationId = existing?.id;
        if (conversationId) {
          await supabaseAdmin
            .from("conversations")
            .update({
              name: existing?.name ?? inbound.name ?? null,
              last_message: inbound.text || `[${inbound.type}]`,
              last_message_at: now,
              last_inbound_at: now,
              unread_count: (existing?.unread_count ?? 0) + 1,
              updated_at: now,
            })
            .eq("id", conversationId);
        } else {
          const { data: created, error } = await supabaseAdmin
            .from("conversations")
            .insert({
              phone: inbound.phone,
              name: inbound.name ?? null,
              last_message: inbound.text || `[${inbound.type}]`,
              last_message_at: now,
              last_inbound_at: now,
              unread_count: 1,
            })
            .select("id")
            .single();
          if (error || !created) {
            return json({ ok: false, error: error?.message ?? "Could not save conversation" }, 500);
          }
          conversationId = created.id;
        }

        const { error: msgError } = await supabaseAdmin.from("messages").insert({
          conversation_id: conversationId,
          phone: inbound.phone,
          wa_message_id: inbound.messageId ?? null,
          direction: "incoming",
          message_type: inbound.type,
          body: inbound.text,
          media_url: inbound.mediaUrl ?? null,
          status: "received",
          raw: payload as never,
        });

        if (msgError && !msgError.message.includes("duplicate")) {
          return json({ ok: false, error: msgError.message }, 500);
        }

        return json({ ok: true, conversationId });
      },
    },
  },
});
