import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Loader2, LogIn, MessageCircle } from "lucide-react";
import { useEffect, useState } from "react";

import { Button } from "@/components/ui/button";
import { requestAccess } from "@/lib/staff.functions";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/auth")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Agent Sign In | WhatsApp Chat Portal" },
      {
        name: "description",
        content:
          "Sign in with your agent or admin account to open the WhatsApp customer chat portal inbox.",
      },
      { property: "og:title", content: "Agent Sign In | WhatsApp Chat Portal" },
      {
        property: "og:description",
        content: "Secure sign-in for admins and agents of the WhatsApp customer chat portal.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [mode, setMode] = useState<"signin" | "request">("signin");
  const [notice, setNotice] = useState<string | null>(null);

  useEffect(() => {
    void supabase.auth.getSession().then(({ data }) => {
      if (data.session) void navigate({ to: "/" });
    });
  }, [navigate]);

  const onSubmit = async (event: React.FormEvent) => {
    event.preventDefault();
    setBusy(true);
    setError(null);
    setNotice(null);

    if (mode === "request") {
      try {
        await requestAccess({ data: { email: email.trim(), password } });
        setNotice(
          "Account created. An admin has to approve it on the Team page before you can sign in.",
        );
        setMode("signin");
      } catch (requestError) {
        setError((requestError as Error).message);
      }
      setBusy(false);
      return;
    }

    const { error: signInError } = await supabase.auth.signInWithPassword({
      email: email.trim(),
      password,
    });
    setBusy(false);
    if (signInError) {
      setError(signInError.message);
      return;
    }
    const { data: user } = await supabase.auth.getUser();
    if (user.user) {
      const { data: access } = await supabase
        .from("staff_access")
        .select("status")
        .eq("user_id", user.user.id)
        .maybeSingle();
      if (access && access.status !== "approved") {
        void navigate({ to: "/pending" });
        return;
      }
    }
    void navigate({ to: "/" });
  };

  return (
    <main className="flex min-h-screen items-center justify-center bg-secondary/40 p-6">
      <div className="w-full max-w-sm rounded-xl border border-border bg-card p-6 shadow-sm">
        <div className="mb-5 flex items-center gap-2.5">
          <span className="flex size-9 items-center justify-center rounded-full bg-brand text-brand-foreground">
            <MessageCircle className="size-4" />
          </span>
          <div>
            <h1 className="text-base font-semibold">Customer Chat Portal</h1>
            <p className="text-xs text-muted-foreground">Admin &amp; agent sign in</p>
          </div>
        </div>

        <form className="space-y-3" onSubmit={onSubmit}>
          <div className="space-y-1.5">
            <Label htmlFor="email">Work email</Label>
            <Input
              id="email"
              type="email"
              autoComplete="username"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="agent1@vyaparapp.in"
              required
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="password">Password</Label>
            <Input
              id="password"
              type="password"
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          {error ? <p className="text-xs text-destructive">{error}</p> : null}
          {notice ? <p className="text-xs text-success">{notice}</p> : null}
          <Button type="submit" className="w-full" disabled={busy}>
            {busy ? <Loader2 className="size-4 animate-spin" /> : <LogIn className="size-4" />}
            {mode === "signin" ? "Sign in" : "Request access"}
          </Button>
          <button
            type="button"
            className="w-full text-center text-xs text-muted-foreground underline-offset-2 hover:underline"
            onClick={() => {
              setMode(mode === "signin" ? "request" : "signin");
              setError(null);
              setNotice(null);
            }}
          >
            {mode === "signin"
              ? "New here? Request portal access"
              : "Already approved? Back to sign in"}
          </button>
        </form>
      </div>
    </main>
  );
}
