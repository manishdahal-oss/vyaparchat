import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { Clock3, LogOut, ShieldAlert } from "lucide-react";
import { useEffect, useState } from "react";

import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/pending")({
  ssr: false,
  head: () => ({
    meta: [
      { title: "Access Pending Approval | WhatsApp Chat Portal" },
      {
        name: "description",
        content:
          "Your portal account is waiting for an administrator to approve access to the WhatsApp customer chat inbox.",
      },
      { property: "og:title", content: "Access Pending Approval | WhatsApp Chat Portal" },
      {
        property: "og:description",
        content: "An admin must approve your account before you can open the chat portal.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: PendingPage,
});

function PendingPage() {
  const navigate = useNavigate();
  const [status, setStatus] = useState<string>("pending");
  const [email, setEmail] = useState("");

  useEffect(() => {
    void (async () => {
      const { data } = await supabase.auth.getUser();
      if (!data.user) {
        void navigate({ to: "/auth" });
        return;
      }
      setEmail(data.user.email ?? "");
      const { data: row } = await supabase
        .from("staff_access")
        .select("status")
        .eq("user_id", data.user.id)
        .maybeSingle();
      if (!row || row.status === "approved") {
        void navigate({ to: "/" });
        return;
      }
      setStatus(row.status);
    })();
  }, [navigate]);

  const revoked = status === "revoked";

  return (
    <main className="flex min-h-screen items-center justify-center bg-secondary/40 p-6">
      <div className="w-full max-w-sm rounded-xl border border-border bg-card p-6 text-center shadow-sm">
        <span className="mx-auto flex size-10 items-center justify-center rounded-full bg-warning/20 text-warning-foreground">
          {revoked ? <ShieldAlert className="size-5" /> : <Clock3 className="size-5" />}
        </span>
        <h1 className="mt-3 text-base font-semibold">
          {revoked ? "Access revoked" : "Waiting for admin approval"}
        </h1>
        <p className="mt-1.5 text-sm text-muted-foreground">
          {revoked
            ? "An administrator has revoked access for this account. Contact your admin to restore it."
            : "Your account was created and is pending approval. An admin will approve it from the Team page, then you can sign in as an agent."}
        </p>
        {email ? <p className="mt-3 text-xs text-muted-foreground">{email}</p> : null}
        <Button
          variant="outline"
          size="sm"
          className="mt-4 gap-1.5"
          onClick={async () => {
            await supabase.auth.signOut();
            window.location.href = "/auth";
          }}
        >
          <LogOut className="size-3.5" /> Sign out
        </Button>
      </div>
    </main>
  );
}
