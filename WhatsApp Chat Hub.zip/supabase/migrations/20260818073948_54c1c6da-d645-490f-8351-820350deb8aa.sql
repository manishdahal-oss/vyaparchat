CREATE TABLE public.conversations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  phone text NOT NULL UNIQUE,
  name text,
  last_message text,
  last_message_at timestamptz,
  last_inbound_at timestamptz,
  unread_count integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.conversations TO anon, authenticated;
GRANT ALL ON public.conversations TO service_role;
ALTER TABLE public.conversations ENABLE ROW LEVEL SECURITY;
CREATE POLICY "conversations_all" ON public.conversations FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

CREATE TABLE public.messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id uuid NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,
  wa_message_id text,
  phone text NOT NULL,
  direction text NOT NULL DEFAULT 'outgoing',
  message_type text NOT NULL DEFAULT 'text',
  body text,
  media_url text,
  template_name text,
  status text NOT NULL DEFAULT 'pending',
  error text,
  raw jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX messages_conversation_idx ON public.messages (conversation_id, created_at);
CREATE UNIQUE INDEX messages_wa_id_idx ON public.messages (wa_message_id) WHERE wa_message_id IS NOT NULL;

GRANT SELECT, INSERT, UPDATE, DELETE ON public.messages TO anon, authenticated;
GRANT ALL ON public.messages TO service_role;
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "messages_all" ON public.messages FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

CREATE TABLE public.templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL UNIQUE,
  language text NOT NULL DEFAULT 'en',
  category text,
  header_type text NOT NULL DEFAULT 'none',
  header_text text,
  header_media_url text,
  body_text text NOT NULL,
  footer_text text,
  buttons jsonb NOT NULL DEFAULT '[]'::jsonb,
  variable_count integer NOT NULL DEFAULT 0,
  status text NOT NULL DEFAULT 'approved',
  created_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.templates TO anon, authenticated;
GRANT ALL ON public.templates TO service_role;
ALTER TABLE public.templates ENABLE ROW LEVEL SECURITY;
CREATE POLICY "templates_all" ON public.templates FOR ALL TO anon, authenticated USING (true) WITH CHECK (true);

ALTER PUBLICATION supabase_realtime ADD TABLE public.messages;
ALTER PUBLICATION supabase_realtime ADD TABLE public.conversations;

INSERT INTO public.templates (name, language, category, header_type, header_text, body_text, footer_text, buttons, variable_count) VALUES
('welcome_back', 'en', 'MARKETING', 'text', 'We miss you!', 'Hi {{1}}, it has been a while. Reply to this message and our team will help you right away.', 'Times Portal', '[{"type":"QUICK_REPLY","text":"Chat with us"}]'::jsonb, 1),
('order_update', 'en', 'UTILITY', 'none', NULL, 'Hello {{1}}, your order {{2}} has been updated. Reply here if you need any help.', NULL, '[]'::jsonb, 2),
('support_followup', 'en', 'UTILITY', 'none', NULL, 'Hi {{1}}, following up on your recent support request. Are you still facing the issue?', 'Support Team', '[{"type":"QUICK_REPLY","text":"Yes"},{"type":"QUICK_REPLY","text":"No"}]'::jsonb, 1);

INSERT INTO public.conversations (phone, name, last_message, last_message_at, last_inbound_at, unread_count) VALUES
('919812345678', 'Ananya Sharma', 'Yes, that works for me. Thanks!', now() - interval '4 minutes', now() - interval '4 minutes', 2),
('919900112233', 'Rohit Menon', 'Could you share the invoice again?', now() - interval '2 hours', now() - interval '2 hours', 0),
('447700900123', 'Elena Fischer', 'Thanks for the update.', now() - interval '3 days', now() - interval '3 days', 0);

INSERT INTO public.messages (conversation_id, phone, direction, message_type, body, status, created_at)
SELECT c.id, c.phone, m.direction, 'text', m.body, m.status, now() - (m.mins || ' minutes')::interval
FROM public.conversations c
JOIN (VALUES
  ('919812345678', 'incoming', 'Hi, I need help with my subscription', 'received', 30),
  ('919812345678', 'outgoing', 'Sure! Could you confirm your registered email?', 'read', 25),
  ('919812345678', 'incoming', 'ananya@example.com', 'received', 10),
  ('919812345678', 'outgoing', 'Thanks, I have extended your plan by 30 days.', 'delivered', 6),
  ('919812345678', 'incoming', 'Yes, that works for me. Thanks!', 'received', 4),
  ('919900112233', 'incoming', 'Could you share the invoice again?', 'received', 120),
  ('447700900123', 'outgoing', 'Your ticket has been resolved.', 'read', 4400),
  ('447700900123', 'incoming', 'Thanks for the update.', 'received', 4320)
) AS m(phone, direction, body, status, mins) ON m.phone = c.phone;