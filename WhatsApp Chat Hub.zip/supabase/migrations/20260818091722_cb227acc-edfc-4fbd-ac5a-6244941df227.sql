CREATE TABLE public.webhook_events (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  received_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  method TEXT NOT NULL,
  parsed BOOLEAN NOT NULL DEFAULT false,
  note TEXT,
  payload JSONB
);
GRANT SELECT ON public.webhook_events TO anon;
GRANT SELECT ON public.webhook_events TO authenticated;
GRANT ALL ON public.webhook_events TO service_role;
ALTER TABLE public.webhook_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Webhook events are readable" ON public.webhook_events FOR SELECT USING (true);