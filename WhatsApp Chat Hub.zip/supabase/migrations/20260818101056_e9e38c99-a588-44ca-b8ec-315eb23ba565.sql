ALTER TABLE public.messages ADD COLUMN IF NOT EXISTS trace_id text;
CREATE INDEX IF NOT EXISTS messages_trace_id_idx ON public.messages (trace_id);

GRANT SELECT, INSERT, UPDATE (trace_id) ON public.messages TO anon, authenticated;
GRANT ALL ON public.messages TO service_role;