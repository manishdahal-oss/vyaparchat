CREATE TABLE public.leads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text,
  phone text NOT NULL UNIQUE,
  agent_email text,
  source text,
  notes text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.leads TO authenticated;
GRANT ALL ON public.leads TO service_role;
ALTER TABLE public.leads ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.current_email()
RETURNS text LANGUAGE sql STABLE AS $$
  SELECT lower(coalesce(auth.jwt() ->> 'email', ''))
$$;

CREATE OR REPLACE FUNCTION public.can_access_phone(_phone text)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT public.has_role(auth.uid(), 'admin'::public.app_role)
     OR EXISTS (
       SELECT 1 FROM public.leads l
       WHERE l.phone = _phone
         AND l.agent_email IS NOT NULL
         AND lower(l.agent_email) = public.current_email()
     )
$$;

CREATE POLICY "leads visible to admin or owning agent" ON public.leads
FOR SELECT TO authenticated
USING (public.has_role(auth.uid(), 'admin'::public.app_role)
       OR (agent_email IS NOT NULL AND lower(agent_email) = public.current_email()));

CREATE POLICY "admins insert leads" ON public.leads
FOR INSERT TO authenticated
WITH CHECK (public.has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "admins update leads" ON public.leads
FOR UPDATE TO authenticated
USING (public.has_role(auth.uid(), 'admin'::public.app_role))
WITH CHECK (public.has_role(auth.uid(), 'admin'::public.app_role));

CREATE POLICY "admins delete leads" ON public.leads
FOR DELETE TO authenticated
USING (public.has_role(auth.uid(), 'admin'::public.app_role));

DROP POLICY IF EXISTS conversations_staff ON public.conversations;
CREATE POLICY conversations_scoped ON public.conversations
FOR SELECT TO authenticated USING (public.can_access_phone(phone));
CREATE POLICY conversations_scoped_update ON public.conversations
FOR UPDATE TO authenticated
USING (public.can_access_phone(phone)) WITH CHECK (public.can_access_phone(phone));

DROP POLICY IF EXISTS messages_staff ON public.messages;
CREATE POLICY messages_scoped ON public.messages
FOR SELECT TO authenticated USING (public.can_access_phone(phone));

CREATE INDEX leads_agent_email_idx ON public.leads (lower(agent_email));