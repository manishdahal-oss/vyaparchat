CREATE OR REPLACE FUNCTION public.current_email()
RETURNS text LANGUAGE sql STABLE SET search_path = public AS $$
  SELECT lower(coalesce(auth.jwt() ->> 'email', ''))
$$;

REVOKE ALL ON FUNCTION public.can_access_phone(text) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.has_role(uuid, public.app_role) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.can_access_phone(text) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated, service_role;