CREATE TABLE public.staff_access (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text NOT NULL,
  status text NOT NULL DEFAULT 'pending',
  requested_at timestamptz NOT NULL DEFAULT now(),
  decided_at timestamptz,
  decided_by uuid
);

GRANT SELECT ON public.staff_access TO authenticated;
GRANT ALL ON public.staff_access TO service_role;

ALTER TABLE public.staff_access ENABLE ROW LEVEL SECURITY;

CREATE POLICY "staff read own access or admin reads all"
ON public.staff_access FOR SELECT TO authenticated
USING (auth.uid() = user_id OR public.has_role(auth.uid(), 'admin'::public.app_role));

INSERT INTO public.staff_access (user_id, email, status, decided_at)
SELECT u.id, coalesce(u.email, ''), 'approved', now() FROM auth.users u
ON CONFLICT (user_id) DO NOTHING;